// tac.h

#define TAC_H

#include "ast.h"

typedef enum {
    TAC_ASSIGN,
    TAC_ADD,
    TAC_SUB,
    TAC_MUL,
    TAC_DIV,
    TAC_LABEL,
    TAC_GOTO,
    TAC_ARRAY_STORE,
    TAC_ARRAY_LOAD,
    TAC_PARAM,
    TAC_CALL,
    TAC_RETURN,
    TAC_WRITE
} TACType;

typedef struct TACNode {
    TACType type;
    char* result;
    char* arg1;
    char* arg2;
    struct TACNode* next;
} TACNode;

typedef struct {
    TACNode* head;
    TACNode* tail;
    int temp_count;
    int label_count;
} TACList;

// Function prototypes
TACList* createTAC(ASTNode* ast);
void printTAC(TACList* tac);
void freeTAC(TACList* tac);
char* newTemp(TACList* list);
char* newLabel(TACList* list);