#include "tac.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Forward declarations
static void processStatement(TACList* list, ASTNode* node);
static char* processExpression(TACList* list, ASTNode* node);

static void addTAC(TACList* list, TACType type, char* result, char* arg1, char* arg2) {
    TACNode* node = malloc(sizeof(TACNode));
    node->type = type;
    node->result = result ? strdup(result) : NULL;
    node->arg1 = arg1 ? strdup(arg1) : NULL;
    node->arg2 = arg2 ? strdup(arg2) : NULL;
    node->next = NULL;

    if (!list->head) {
        list->head = list->tail = node;
    } else {
        list->tail->next = node;
        list->tail = node;
    }
}

char* newTemp(TACList* list) {
    char* temp = malloc(20);
    sprintf(temp, "t%d", list->temp_count++);
    return temp;
}

char* newLabel(TACList* list) {
    char* label = malloc(20);
    sprintf(label, "L%d", list->label_count++);
    return label;
}

static char* processExpression(TACList* list, ASTNode* node) {
    if (!node) return NULL;

    switch (node->type) {
        case NODE_INT_NUMBER:
        case NODE_FLOAT_NUMBER:
        case NODE_ID:
            return strdup(node->value);

        case NODE_EXPRESSION:
        case NODE_TERM: {
            char* left = processExpression(list, node->children[0]);
            char* right = processExpression(list, node->children[1]);
            char* temp = newTemp(list);
            TACType op;

            if (strcmp(node->value, "+") == 0) op = TAC_ADD;
            else if (strcmp(node->value, "-") == 0) op = TAC_SUB;
            else if (strcmp(node->value, "*") == 0) op = TAC_MUL;
            else if (strcmp(node->value, "/") == 0) op = TAC_DIV;

            addTAC(list, op, temp, left, right);
            free(left);
            free(right);
            return temp;
        }

        case NODE_FUNCTION_CALL: {
            char* temp = newTemp(list);
            
            // Process arguments
            if (node->children[0]) {
                for (int i = 0; i < node->children[0]->childCount; i++) {
                    char* arg = processExpression(list, node->children[0]->children[i]);
                    addTAC(list, TAC_PARAM, NULL, arg, NULL);
                    free(arg);
                }
            }
            
            addTAC(list, TAC_CALL, temp, node->value, NULL);
            return temp;
        }

        default:
            return NULL;
    }
}

static void processStatement(TACList* list, ASTNode* node) {
    switch (node->type) {
        case NODE_VAR_DECLARATION:
        case NODE_ARRAY_DECLARATION:
            break;

        case NODE_ASSIGNMENT: {
            char* expr = processExpression(list, node->children[0]);
            addTAC(list, TAC_ASSIGN, node->value, expr, NULL);
            free(expr);
            break;
        }

        case NODE_ARRAY_ASSIGNMENT: {
            // For array assignments, children[0] is the index expression
            // and children[1] is the value to store
            char* indexExpr = processExpression(list, node->children[0]);
            char* valueExpr = processExpression(list, node->children[1]);
            
            // Create TAC node with all three parts properly filled
            addTAC(list, TAC_ARRAY_STORE, 
                   node->value,  // array name
                   indexExpr,    // index
                   valueExpr);   // value to store
            
            free(indexExpr);
            free(valueExpr);
            break;
        }

        case NODE_WRITE_STATEMENT: {
            if (node->childCount > 0) {
                char* indexExpr = processExpression(list, node->children[0]);
                char* temp = newTemp(list);
                
                // Create proper array load with all parts filled
                addTAC(list, TAC_ARRAY_LOAD, 
                       temp,        // result
                       node->value, // array name
                       indexExpr);  // index
                       
                addTAC(list, TAC_WRITE, NULL, temp, NULL);
                free(indexExpr);
                free(temp);
            } else {
                addTAC(list, TAC_WRITE, NULL, node->value, NULL);
            }
            break;
        }
    }
}
static void processFunctionDefinition(TACList* list, ASTNode* node) {
    char* funcName = node->value;
    addTAC(list, TAC_LABEL, funcName, NULL, NULL);

    if (node->childCount >= 3) {
        ASTNode* stmtList = node->children[2];
        for (int i = 0; i < stmtList->childCount; i++) {
            processStatement(list, stmtList->children[i]);
        }
    }

    if (node->childCount >= 4) {
        ASTNode* returnStmt = node->children[3];
        if (returnStmt->childCount > 0) {
            char* retVal = processExpression(list, returnStmt->children[0]);
            addTAC(list, TAC_RETURN, NULL, retVal, NULL);
            free(retVal);
        }
    }
}

TACList* createTAC(ASTNode* ast) {
    TACList* list = malloc(sizeof(TACList));
    list->head = list->tail = NULL;
    list->temp_count = list->label_count = 0;

    if (!ast) return list;

    // Process main function
    ASTNode* mainFunc = ast->children[0];
    if (mainFunc) {
        addTAC(list, TAC_LABEL, "main", NULL, NULL);
        
        // Process main function statements
        ASTNode* stmtList = mainFunc->children[0];
        for (int i = 0; i < stmtList->childCount; i++) {
            processStatement(list, stmtList->children[i]);
        }

        // Process main return statement
        if (mainFunc->childCount > 1) {
            ASTNode* returnStmt = mainFunc->children[1];
            if (returnStmt->childCount > 0) {
                char* retVal = processExpression(list, returnStmt->children[0]);
                addTAC(list, TAC_RETURN, NULL, retVal, NULL);
                free(retVal);
            }
        }
    }

    // Process other functions
    ASTNode* funcList = ast->children[1];
    for (int i = 0; i < funcList->childCount; i++) {
        processFunctionDefinition(list, funcList->children[i]);
    }

    return list;
}

void printTAC(TACList* list) {
    if (!list) return;

    TACNode* current = list->head;
    while (current) {
        switch (current->type) {
            case TAC_ASSIGN:
                printf("%s := %s\n", current->result, current->arg1);
                break;
            case TAC_ADD:
                printf("%s := %s + %s\n", current->result, current->arg1, current->arg2);
                break;
            case TAC_SUB:
                printf("%s := %s - %s\n", current->result, current->arg1, current->arg2);
                break;
            case TAC_MUL:
                printf("%s := %s * %s\n", current->result, current->arg1, current->arg2);
                break;
            case TAC_DIV:
                printf("%s := %s / %s\n", current->result, current->arg1, current->arg2);
                break;
            case TAC_LABEL:
                printf("%s:\n", current->result);
                break;
            case TAC_GOTO:
                printf("goto %s\n", current->result);
                break;
            case TAC_ARRAY_STORE:
                printf("%s[%s] := %s\n", current->result, current->arg1, current->arg2);
                break;
            case TAC_ARRAY_LOAD:
                printf("%s := %s[%s]\n", current->result, current->arg1, current->arg2);
                break;
            case TAC_PARAM:
                printf("param %s\n", current->arg1);
                break;
            case TAC_CALL:
                printf("%s := call %s\n", current->result, current->arg1);
                break;
            case TAC_RETURN:
                printf("return %s\n", current->arg1);
                break;
            case TAC_WRITE:
                printf("write %s\n", current->arg1);
                break;
        }
        current = current->next;
    }
}

void freeTAC(TACList* list) {
    if (!list) return;

    TACNode* current = list->head;
    while (current) {
        TACNode* next = current->next;
        free(current->result);
        free(current->arg1);
        free(current->arg2);
        free(current);
        current = next;
    }
    free(list);
}