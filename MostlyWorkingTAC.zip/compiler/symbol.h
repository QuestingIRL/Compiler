#ifndef SYMBOL_H
#define SYMBOL_H

#include <stdbool.h>


// Symbol types
typedef enum {
    TYPE_INT,
    TYPE_FLOAT,
    TYPE_BOOL,
    TYPE_FUNCTION,
    TYPE_ARRAY
} SymbolType;

// Symbol structure
typedef struct Symbol {
    char* name;                  // Name of the symbol
    SymbolType type;            // Type of the symbol
    int scope_level;            // Scope level where symbol is declared
    bool initialized;           // Whether the symbol has been initialized
    struct Symbol* next;        // Next symbol in the hash table bucket
    
    // Additional information for different symbol types
    union {
        // For arrays
        struct {
            SymbolType element_type;  // Type of array elements
            int size;                 // Size of the array
        } array_info;
        
        // For functions
        struct {
            SymbolType return_type;   // Return type of the function
            struct ParameterList* params;  // List of parameters
        } function_info;
    };
} Symbol;

// Parameter list for functions
typedef struct ParameterList {
    SymbolType type;
    char* name;
    struct ParameterList* next;
} ParameterList;

typedef struct ScopeNode {
    int scope_level;
    struct ScopeNode* next;
} ScopeNode;

typedef struct {
    Symbol** table;             // Hash table array
    int size;                   // Size of the hash table
    int current_scope;          // Current scope level
    ScopeNode* scope_stack;    // Stack to track scope levels
} SymbolTable;

// Function declarations
SymbolTable* initializeTable(int size);
void destroyTable(SymbolTable* table);
bool insertSymbol(SymbolTable* table, const char* name, SymbolType type, bool initialized);
bool insertArraySymbol(SymbolTable* table, const char* name, SymbolType element_type, int size);
bool insertFunctionSymbol(SymbolTable* table, const char* name, SymbolType return_type, ParameterList* params);
Symbol* lookupSymbol(SymbolTable* table, const char* name);
void enterScope(SymbolTable* table);
void exitScope(SymbolTable* table);
void printSymbolTable(SymbolTable* table);

void pushScope(SymbolTable* table);
void popScope(SymbolTable* table);

// Helper functions
const char* getTypeString(SymbolType type);
void printSymbol(Symbol* symbol);

#endif // SYMBOL_H