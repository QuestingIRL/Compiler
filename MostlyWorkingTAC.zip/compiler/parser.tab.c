/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "parser.y"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>  // Add this line
#include "ast.h"
#include "symbol.h"
#include "tac.h"

extern int yylex();
extern int yylineno;
void yyerror(const char *s);
// Function prototypes
void setInMain(bool value);
bool isInMain(void);

/* Root of the AST */
ASTNode* ast_root = NULL;

/* Global symbol table */
SymbolTable* symbolTable = NULL;



static int semantic_error_count = 0;

// Function prototypes
static SymbolType getExpressionType(ASTNode* node);
static bool checkTypeCompatibility(SymbolType type1, SymbolType type2, const char* operation);


void semanticAnalysis(ASTNode* root) {
    if (!root) return;
    
    switch (root->type) {
        case NODE_ASSIGNMENT: {
            Symbol* sym = lookupSymbol(symbolTable, root->value);
            if (!sym) {
                fprintf(stderr, "Semantic Error: Variable '%s' used before declaration\n", root->value);
                semantic_error_count++;
                return;
            }
            
            SymbolType exprType = getExpressionType(root->children[0]);
            if (!checkTypeCompatibility(sym->type, exprType, "assignment")) {
                fprintf(stderr, "Semantic Error: Type mismatch in assignment to '%s'\n", root->value);
                semantic_error_count++;
            }
            sym->initialized = true;
            break;
        }
        
        case NODE_FUNCTION_CALL: {
            Symbol* func = lookupSymbol(symbolTable, root->value);
            if (!func || func->type != TYPE_FUNCTION) {
                fprintf(stderr, "Semantic Error: Undefined function '%s'\n", root->value);
                semantic_error_count++;
                return;
            }
            
            // Check argument count and types
            ASTNode* args = root->children[0];  // ArgList node
            ParameterList* params = func->function_info.params;
            
            int argCount = args ? args->childCount : 0;
            int paramCount = 0;
            for (ParameterList* p = params; p; p = p->next) paramCount++;
            
            if (argCount != paramCount) {
                fprintf(stderr, "Semantic Error: Function '%s' called with wrong number of arguments\n", root->value);
                semantic_error_count++;
                return;
            }
            
            // Check argument types
            ParameterList* param = params;
            for (int i = 0; i < argCount && param; i++) {
                SymbolType argType = getExpressionType(args->children[i]);
                if (!checkTypeCompatibility(param->type, argType, "function argument")) {
                    fprintf(stderr, "Semantic Error: Type mismatch in argument %d of function '%s'\n", i + 1, root->value);
                            semantic_error_count++;
                }
                param = param->next;
            }
            break;
        }
        
        case NODE_ARRAY_ASSIGNMENT: {
            Symbol* array = lookupSymbol(symbolTable, root->value);
            if (!array || array->type != TYPE_ARRAY) {
                fprintf(stderr, "Semantic Error: Array '%s' not declared\n", root->value);
                semantic_error_count++;
                return;
            }
            
            // Check index bounds if it's a constant
            ASTNode* indexNode = root->children[0];
            if (indexNode->type == NODE_INT_NUMBER) {
                int index = atoi(indexNode->value);
                if (index < 0 || index >= array->array_info.size) {
                    fprintf(stderr, "Semantic Error: Array index out of bounds for '%s'\n", root->value);
                    semantic_error_count++;
                }
            }
            
            // Check assignment type compatibility
            SymbolType exprType = getExpressionType(root->children[1]);
            if (!checkTypeCompatibility(array->array_info.element_type, exprType, "array assignment")) {
                fprintf(stderr, "Semantic Error: Type mismatch in array assignment to '%s'\n", root->value);
                semantic_error_count++;
            }
            break;
        }
        
        // Add this case in the switch statement in semanticAnalysis():
        case NODE_WRITE_STATEMENT: {
            if (root->childCount > 0) {  // This means it's an array access
                Symbol* array = lookupSymbol(symbolTable, root->value);
                if (!array || array->type != TYPE_ARRAY) {
                    fprintf(stderr, "Semantic Error: Array '%s' not declared\n", root->value);
                    semantic_error_count++;
                    return;
                }
                
                // Check index bounds if it's a constant
                ASTNode* indexNode = root->children[0];
                if (indexNode->type == NODE_INT_NUMBER) {
                    int index = atoi(indexNode->value);
                    if (index < 0 || index >= array->array_info.size) {
                        fprintf(stderr, "Semantic Error: Array index out of bounds in write statement for '%s'\n", root->value);
                        semantic_error_count++;
                    }
                }
            }
            break;
        }
        
        case NODE_RETURN_STATEMENT: {
            // TODO: Check return type matches function declaration
            break;
        }
    }
    
    // Recursively analyze children
    for (int i = 0; i < root->childCount; i++) {
        semanticAnalysis(root->children[i]);
    }
}

static SymbolType getExpressionType(ASTNode* node) {
    if (!node) return -1;
    
    switch (node->type) {
        case NODE_INT_NUMBER:
            return TYPE_INT;
            
        case NODE_FLOAT_NUMBER:
            return TYPE_FLOAT;
            
        case NODE_ID: {
            Symbol* sym = lookupSymbol(symbolTable, node->value);
            return sym ? sym->type : -1;
        }
        
        case NODE_FUNCTION_CALL: {
            Symbol* func = lookupSymbol(symbolTable, node->value);
            return func ? func->function_info.return_type : -1;
        }
        
        case NODE_EXPRESSION:
        case NODE_TERM: {
            SymbolType leftType = getExpressionType(node->children[0]);
            SymbolType rightType = getExpressionType(node->children[1]);
            
            // If both operands are float, result is float
            if (leftType == TYPE_FLOAT || rightType == TYPE_FLOAT)
                return TYPE_FLOAT;
            
            // Otherwise result is int
            return TYPE_INT;
        }
    }
    
    return -1;
}

static bool checkTypeCompatibility(SymbolType type1, SymbolType type2, const char* operation) {
    // Allow int to float conversion
    if (type1 == TYPE_FLOAT && type2 == TYPE_INT)
        return true;
        
    // Otherwise types must match exactly
    return type1 == type2;
}

bool hasSemanticErrors() {
    return semantic_error_count > 0;
}





























/* Helper functions for semantic analysis */
SymbolType convertType(const char* typeStr) {
    if (strcmp(typeStr, "int") == 0) return TYPE_INT;
    if (strcmp(typeStr, "float") == 0) return TYPE_FLOAT;
    if (strcmp(typeStr, "bool") == 0) return TYPE_BOOL;
    return -1;
}

/* Function to check if two types are compatible for operations */
bool areTypesCompatible(SymbolType type1, SymbolType type2) {
    return type1 == type2 && (type1 == TYPE_INT || type1 == TYPE_FLOAT);
}

/* Convert AST ParamList to ParameterList for symbol table */
ParameterList* convertToParameterList(ASTNode* paramList) {
    if (!paramList || paramList->childCount == 0) return NULL;

    ParameterList* head = NULL;
    ParameterList* current = NULL;

    for (int i = 0; i < paramList->childCount; i++) {
        ASTNode* param = paramList->children[i];
        ParameterList* newParam = (ParameterList*)malloc(sizeof(ParameterList));
        newParam->name = strdup(param->value);
        newParam->type = convertType(param->children[0]->value);
        newParam->next = NULL;

        if (!head) {
            head = newParam;
            current = head;
        } else {
            current->next = newParam;
            current = newParam;
        }
    }
    return head;
}

/* Function to verify function call arguments */
bool verifyFunctionArgs(const char* funcName, ASTNode* argList) {
    Symbol* func = lookupSymbol(symbolTable, funcName);
    if (!func || func->type != TYPE_FUNCTION) {
        // Don't error immediately - the function might be defined later
        return true;
    }

    ParameterList* param = func->function_info.params;
    int argCount = (argList != NULL) ? argList->childCount : 0;
    int paramCount = 0;
    for (ParameterList* p = param; p != NULL; p = p->next) paramCount++;

    if (argCount != paramCount) {
        fprintf(stderr, "Warning: Argument count mismatch in function '%s' at line %d\n", 
                funcName, yylineno);
        return true; // Continue parsing
    }
    return true;
}


#line 359 "parser.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "parser.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_TYPE = 3,                       /* TYPE  */
  YYSYMBOL_ID = 4,                         /* ID  */
  YYSYMBOL_FUNCTION = 5,                   /* FUNCTION  */
  YYSYMBOL_RETURN = 6,                     /* RETURN  */
  YYSYMBOL_MAIN = 7,                       /* MAIN  */
  YYSYMBOL_WRITE = 8,                      /* WRITE  */
  YYSYMBOL_INT_NUMBER = 9,                 /* INT_NUMBER  */
  YYSYMBOL_FLOAT_NUMBER = 10,              /* FLOAT_NUMBER  */
  YYSYMBOL_SEMICOLON = 11,                 /* SEMICOLON  */
  YYSYMBOL_COMMA = 12,                     /* COMMA  */
  YYSYMBOL_EQ = 13,                        /* EQ  */
  YYSYMBOL_PLUS = 14,                      /* PLUS  */
  YYSYMBOL_SUB = 15,                       /* SUB  */
  YYSYMBOL_MULTIPLY = 16,                  /* MULTIPLY  */
  YYSYMBOL_DIV = 17,                       /* DIV  */
  YYSYMBOL_LPAREN = 18,                    /* LPAREN  */
  YYSYMBOL_RPAREN = 19,                    /* RPAREN  */
  YYSYMBOL_LBRACE = 20,                    /* LBRACE  */
  YYSYMBOL_RBRACE = 21,                    /* RBRACE  */
  YYSYMBOL_LBRACKET = 22,                  /* LBRACKET  */
  YYSYMBOL_RBRACKET = 23,                  /* RBRACKET  */
  YYSYMBOL_YYACCEPT = 24,                  /* $accept  */
  YYSYMBOL_Program = 25,                   /* Program  */
  YYSYMBOL_26_1 = 26,                      /* $@1  */
  YYSYMBOL_MainFunction = 27,              /* MainFunction  */
  YYSYMBOL_28_2 = 28,                      /* $@2  */
  YYSYMBOL_29_3 = 29,                      /* $@3  */
  YYSYMBOL_FunctionList = 30,              /* FunctionList  */
  YYSYMBOL_Function = 31,                  /* Function  */
  YYSYMBOL_32_4 = 32,                      /* $@4  */
  YYSYMBOL_33_5 = 33,                      /* $@5  */
  YYSYMBOL_WriteStatement = 34,            /* WriteStatement  */
  YYSYMBOL_ParamList = 35,                 /* ParamList  */
  YYSYMBOL_Param = 36,                     /* Param  */
  YYSYMBOL_StatementList = 37,             /* StatementList  */
  YYSYMBOL_Statement = 38,                 /* Statement  */
  YYSYMBOL_VarDeclaration = 39,            /* VarDeclaration  */
  YYSYMBOL_Assignment = 40,                /* Assignment  */
  YYSYMBOL_ArrayDeclaration = 41,          /* ArrayDeclaration  */
  YYSYMBOL_ArrayAssignment = 42,           /* ArrayAssignment  */
  YYSYMBOL_ReturnStatement = 43,           /* ReturnStatement  */
  YYSYMBOL_Expression = 44,                /* Expression  */
  YYSYMBOL_Term = 45,                      /* Term  */
  YYSYMBOL_Factor = 46,                    /* Factor  */
  YYSYMBOL_ArgList = 47                    /* ArgList  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   78

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  24
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  24
/* YYNRULES -- Number of rules.  */
#define YYNRULES  44
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  92

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   278


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   308,   308,   308,   327,   336,   326,   353,   364,   371,
     396,   370,   430,   449,   478,   481,   486,   494,   518,   529,
     535,   536,   537,   538,   539,   545,   589,   608,   643,   666,
     672,   678,   684,   690,   697,   703,   709,   716,   722,   728,
     742,   751,   759,   762,   767
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "TYPE", "ID",
  "FUNCTION", "RETURN", "MAIN", "WRITE", "INT_NUMBER", "FLOAT_NUMBER",
  "SEMICOLON", "COMMA", "EQ", "PLUS", "SUB", "MULTIPLY", "DIV", "LPAREN",
  "RPAREN", "LBRACE", "RBRACE", "LBRACKET", "RBRACKET", "$accept",
  "Program", "$@1", "MainFunction", "$@2", "$@3", "FunctionList",
  "Function", "$@4", "$@5", "WriteStatement", "ParamList", "Param",
  "StatementList", "Statement", "VarDeclaration", "Assignment",
  "ArrayDeclaration", "ArrayAssignment", "ReturnStatement", "Expression",
  "Term", "Factor", "ArgList", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-28)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int8 yypact[] =
{
     -28,    12,    26,   -28,   -28,    19,    23,    39,   -28,    19,
     -28,    42,   -28,     7,   -28,    -2,    -6,    31,   -28,    44,
       7,   -28,   -28,   -28,   -28,    33,    41,    45,    -1,    46,
      49,    -1,    35,   -28,   -28,   -28,    34,    40,   -28,   -28,
      -1,    10,    11,   -28,    36,    18,    15,   -28,    57,    58,
      -1,     4,   -28,    -1,    -1,    -1,    -1,    48,    53,    -1,
     -28,    61,    47,    55,    59,    24,    50,   -28,    11,    11,
     -28,   -28,    -1,   -28,    -9,   -28,    51,    57,   -28,    -1,
     -28,    20,    54,     7,   -28,   -28,   -28,    63,    44,   -28,
      56,   -28
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       2,     0,     0,     1,     4,     8,     0,     0,     3,     8,
       5,     0,     7,    19,     9,     0,     0,     0,    24,    30,
      19,    20,    21,    22,    23,     0,     0,     0,     0,     0,
       0,     0,     0,    18,    10,    25,     0,    39,    37,    38,
       0,     0,    33,    36,     0,     0,     0,     6,    14,     0,
      42,     0,    26,     0,     0,     0,     0,     0,     0,     0,
      29,     0,     0,    15,     0,    43,     0,    41,    31,    32,
      34,    35,     0,    12,     0,    17,     0,    14,    27,    42,
      40,     0,     0,    19,    16,    44,    28,     0,    30,    13,
       0,    11
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int8 yypgoto[] =
{
     -28,   -28,   -28,   -28,   -28,   -28,    66,   -28,   -28,   -28,
     -28,    -5,   -28,   -20,   -28,   -28,   -28,   -28,   -28,   -10,
     -27,   -12,    -8,   -11
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int8 yydefgoto[] =
{
       0,     1,     2,     5,     6,    13,     8,     9,    25,    48,
      18,    62,    63,    19,    20,    21,    22,    23,    24,    32,
      65,    42,    43,    66
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int8 yytable[] =
{
      33,    41,    26,    37,    46,    53,    54,    28,    38,    39,
      15,    16,     3,    51,    82,    17,    29,    40,    53,    54,
      27,    52,     7,    67,    53,    54,    60,    55,    56,    53,
      54,    86,    74,     4,    53,    54,    79,    58,    53,    54,
      59,    68,    69,    10,    11,    81,    14,    70,    71,    30,
      31,    34,    35,    45,    36,    44,    47,    49,    50,    57,
      61,    72,    64,    88,    73,    75,    76,    77,    85,    80,
      78,    83,    84,    87,    89,    12,     0,    91,    90
};

static const yytype_int8 yycheck[] =
{
      20,    28,     4,     4,    31,    14,    15,    13,     9,    10,
       3,     4,     0,    40,    23,     8,    22,    18,    14,    15,
      22,    11,     3,    19,    14,    15,    11,    16,    17,    14,
      15,    11,    59,     7,    14,    15,    12,    19,    14,    15,
      22,    53,    54,    20,     5,    72,     4,    55,    56,    18,
       6,    18,    11,     4,     9,     9,    21,    23,    18,    23,
       3,    13,     4,    83,    11,     4,    19,    12,    79,    19,
      11,    20,    77,    19,    11,     9,    -1,    21,    88
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,    25,    26,     0,     7,    27,    28,     3,    30,    31,
      20,     5,    30,    29,     4,     3,     4,     8,    34,    37,
      38,    39,    40,    41,    42,    32,     4,    22,    13,    22,
      18,     6,    43,    37,    18,    11,     9,     4,     9,    10,
      18,    44,    45,    46,     9,     4,    44,    21,    33,    23,
      18,    44,    11,    14,    15,    16,    17,    23,    19,    22,
      11,     3,    35,    36,     4,    44,    47,    19,    45,    45,
      46,    46,    13,    11,    44,     4,    19,    12,    11,    12,
      19,    44,    23,    20,    35,    47,    11,    19,    37,    11,
      43,    21
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    24,    26,    25,    28,    29,    27,    30,    30,    32,
      33,    31,    34,    34,    35,    35,    35,    36,    37,    37,
      38,    38,    38,    38,    38,    39,    40,    41,    42,    43,
      43,    44,    44,    44,    45,    45,    45,    46,    46,    46,
      46,    46,    47,    47,    47
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     0,     3,     0,     0,     7,     2,     0,     0,
       0,    12,     5,     8,     0,     1,     3,     2,     2,     0,
       1,     1,     1,     1,     1,     3,     4,     6,     7,     3,
       0,     3,     3,     1,     3,     3,     1,     1,     1,     1,
       4,     3,     0,     1,     3
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* $@1: %empty  */
#line 308 "parser.y"
    {
        // Initialize symbol table at the very beginning
        symbolTable = initializeTable(211);
        if (!symbolTable) {
            yyerror("Failed to initialize symbol table");
            YYABORT;
        }
    }
#line 1452 "parser.tab.c"
    break;

  case 3: /* Program: $@1 MainFunction FunctionList  */
#line 317 "parser.y"
    {
        (yyval.ast) = createNode(NODE_PROGRAM, NULL);
        addChild((yyval.ast), (yyvsp[-1].ast));
        addChild((yyval.ast), (yyvsp[0].ast));
        ast_root = (yyval.ast);
    }
#line 1463 "parser.tab.c"
    break;

  case 4: /* $@2: %empty  */
#line 327 "parser.y"
    {
        setInMain(true);
        if (!insertFunctionSymbol(symbolTable, "main", TYPE_INT, NULL)) {
            yyerror("Failed to insert main function into symbol table");
            YYABORT;
        }
        printf("Debug: Inserted main function into symbol table\n");
    }
#line 1476 "parser.tab.c"
    break;

  case 5: /* $@3: %empty  */
#line 336 "parser.y"
    {
        pushScope(symbolTable);  // Use pushScope instead of enterScope
        //scopeCount++;
        printf("Debug: Entered new scope for main function\n");
    }
#line 1486 "parser.tab.c"
    break;

  case 6: /* MainFunction: MAIN $@2 LBRACE $@3 StatementList ReturnStatement RBRACE  */
#line 342 "parser.y"
    {
        (yyval.ast) = createNode(NODE_MAIN_FUNCTION, NULL);
        addChild((yyval.ast), (yyvsp[-2].ast)); // StatementList
        addChild((yyval.ast), (yyvsp[-1].ast)); // ReturnStatement
        
        printf("Debug: Exiting scope for main function\n");
        popScope(symbolTable);  // Use popScope instead of exitScope
    }
#line 1499 "parser.tab.c"
    break;

  case 7: /* FunctionList: Function FunctionList  */
#line 354 "parser.y"
    {
        (yyval.ast) = createNode(NODE_FUNCTION_LIST, NULL);
        addChild((yyval.ast), (yyvsp[-1].ast));
        for (int i = 0; i < (yyvsp[0].ast)->childCount; i++) {
            addChild((yyval.ast), (yyvsp[0].ast)->children[i]);
        }
        free((yyvsp[0].ast)->children);
        free((yyvsp[0].ast));
    }
#line 1513 "parser.tab.c"
    break;

  case 8: /* FunctionList: %empty  */
#line 364 "parser.y"
    {
        (yyval.ast) = createNode(NODE_FUNCTION_LIST, NULL);
    }
#line 1521 "parser.tab.c"
    break;

  case 9: /* $@4: %empty  */
#line 371 "parser.y"
    {
        // Pre-declare function in symbol table at global scope
        SymbolType returnType = convertType((yyvsp[-2].string));
        if (returnType == -1) {
            fprintf(stderr, "Error: Invalid return type '%s' at line %d\n", (yyvsp[-2].string), yylineno);
            YYABORT;
        }

        if (!insertFunctionSymbol(symbolTable, (yyvsp[0].string), returnType, NULL)) {
            fprintf(stderr, "Error: Failed to insert function '%s' into symbol table at line %d\n", 
                    (yyvsp[0].string), yylineno);
            YYABORT;
        }
        printf("Debug: Inserted function %s with return type %s into symbol table\n", (yyvsp[0].string), (yyvsp[-2].string));

        if (strcmp((yyvsp[0].string), "main") == 0) {
            setInMain(true);  // Set inMain to true when entering 'main'
            printf("Debug: Entering main function\n");
        } else {
            setInMain(false); // Ensure inMain is false for non-main functions
            //pushScope(symbolTable);
        }

    }
#line 1550 "parser.tab.c"
    break;

  case 10: /* $@5: %empty  */
#line 396 "parser.y"
    {
        // pushScope(symbolTable);  // Use pushScope instead of enterScope
        // printf("Debug: Entered new scope for function %s\n", $3);
        if (!isInMain()) {
            pushScope(symbolTable);  

            printf("Debug: Entered new scope for function %s\n", (yyvsp[-2].string));
        }
    }
#line 1564 "parser.tab.c"
    break;

  case 11: /* Function: TYPE FUNCTION ID $@4 LPAREN $@5 ParamList RPAREN LBRACE StatementList ReturnStatement RBRACE  */
#line 406 "parser.y"
    {
            //pushScope(symbolTable);
        (yyval.ast) = createNode(NODE_FUNCTION, (yyvsp[-9].string));
        ASTNode* typeNode = createNode(NODE_TYPE, (yyvsp[-11].string));
        addChild((yyval.ast), typeNode);
        addChild((yyval.ast), (yyvsp[-5].ast));  // ParamList
        addChild((yyval.ast), (yyvsp[-2].ast)); // StatementList
        addChild((yyval.ast), (yyvsp[-1].ast)); // ReturnStatement

        // Update function symbol with parameters
        Symbol* funcSymbol = lookupSymbol(symbolTable, (yyvsp[-9].string));
        if (funcSymbol) {
            ParameterList* params = convertToParameterList((yyvsp[-5].ast));
            funcSymbol->function_info.params = params;
        }
        
        printf("Debug: Exiting scope for function %s\n", (yyvsp[-9].string));
        popScope(symbolTable);  // Use popScope instead of exitScope
        symbolTable->current_scope = 0;
        
    }
#line 1590 "parser.tab.c"
    break;

  case 12: /* WriteStatement: WRITE LPAREN ID RPAREN SEMICOLON  */
#line 431 "parser.y"
    {
        (yyval.ast) = createNode(NODE_WRITE_STATEMENT, (yyvsp[-2].string));
        
        // Verify variable exists in symbol table
        Symbol* sym = lookupSymbol(symbolTable, (yyvsp[-2].string));
        if (!sym) {
            fprintf(stderr, "Error: Undefined variable '%s' in write statement at line %d\n", 
                    (yyvsp[-2].string), yylineno);
            YYABORT;
        }

        // Check if variable is initialized
        if (!sym->initialized && sym->type != TYPE_ARRAY) {
            fprintf(stderr, "Warning: Writing uninitialized variable '%s' at line %d\n", 
                    (yyvsp[-2].string), yylineno);
        }
        printf("Debug: Processing write statement for variable %s\n", (yyvsp[-2].string));
    }
#line 1613 "parser.tab.c"
    break;

  case 13: /* WriteStatement: WRITE LPAREN ID LBRACKET Expression RBRACKET RPAREN SEMICOLON  */
#line 450 "parser.y"
    {
        (yyval.ast) = createNode(NODE_WRITE_STATEMENT, (yyvsp[-5].string));
        ASTNode* indexNode = (yyvsp[-3].ast);
        addChild((yyval.ast), indexNode);

        // Verify array exists in symbol table
        Symbol* sym = lookupSymbol(symbolTable, (yyvsp[-5].string));
        if (!sym) {
            fprintf(stderr, "Error: Undefined array '%s' in write statement at line %d\n", 
                    (yyvsp[-5].string), yylineno);
            YYABORT;
        }

        // Verify it's an array
        if (sym->type != TYPE_ARRAY) {
            fprintf(stderr, "Error: Variable '%s' is not an array at line %d\n", 
                    (yyvsp[-5].string), yylineno);
            YYABORT;
        }

        // Note: We can't check array bounds at compile time if the index is an expression
        // We'll need to generate appropriate runtime checks
        printf("Debug: Processing write statement for array %s\n", (yyvsp[-5].string));
    }
#line 1642 "parser.tab.c"
    break;

  case 14: /* ParamList: %empty  */
#line 478 "parser.y"
    {
        (yyval.ast) = createNode(NODE_PARAM_LIST, NULL);
    }
#line 1650 "parser.tab.c"
    break;

  case 15: /* ParamList: Param  */
#line 482 "parser.y"
    {
        (yyval.ast) = createNode(NODE_PARAM_LIST, NULL);
        addChild((yyval.ast), (yyvsp[0].ast));
    }
#line 1659 "parser.tab.c"
    break;

  case 16: /* ParamList: Param COMMA ParamList  */
#line 487 "parser.y"
    {
        (yyval.ast) = (yyvsp[0].ast);
        addChild((yyval.ast), (yyvsp[-2].ast));
    }
#line 1668 "parser.tab.c"
    break;

  case 17: /* Param: TYPE ID  */
#line 495 "parser.y"
    {
        (yyval.ast) = createNode(NODE_PARAM, (yyvsp[0].string));
        ASTNode* typeNode = createNode(NODE_TYPE, (yyvsp[-1].string));
        addChild((yyval.ast), typeNode);

        // Add parameter to symbol table
        SymbolType type = convertType((yyvsp[-1].string));
        if (type == -1) {
            fprintf(stderr, "Error: Invalid parameter type '%s' at line %d\n", (yyvsp[-1].string), yylineno);
            YYABORT;
        }

        // Parameters are initialized by definition
        if (!insertSymbol(symbolTable, (yyvsp[0].string), type, true)) {
            fprintf(stderr, "Error: Failed to insert parameter '%s' into symbol table at line %d\n", 
                    (yyvsp[0].string), yylineno);
            YYABORT;
        }
        printf("Debug: Inserted parameter %s of type %s into symbol table\n", (yyvsp[0].string), (yyvsp[-1].string));
    }
#line 1693 "parser.tab.c"
    break;

  case 18: /* StatementList: Statement StatementList  */
#line 519 "parser.y"
    {
        (yyval.ast) = createNode(NODE_STATEMENT_LIST, NULL);
        addChild((yyval.ast), (yyvsp[-1].ast));
        for (int i = 0; i < (yyvsp[0].ast)->childCount; i++) {
            addChild((yyval.ast), (yyvsp[0].ast)->children[i]);
        }
        free((yyvsp[0].ast)->children);
        free((yyvsp[0].ast));
    }
#line 1707 "parser.tab.c"
    break;

  case 19: /* StatementList: %empty  */
#line 529 "parser.y"
    {
        (yyval.ast) = createNode(NODE_STATEMENT_LIST, NULL);
    }
#line 1715 "parser.tab.c"
    break;

  case 25: /* VarDeclaration: TYPE ID SEMICOLON  */
#line 546 "parser.y"
    {
        (yyval.ast) = createNode(NODE_VAR_DECLARATION, (yyvsp[-1].string));
        ASTNode* typeNode = createNode(NODE_TYPE, (yyvsp[-2].string));
        addChild((yyval.ast), typeNode);

        // Add variable to symbol table with proper type conversion
        SymbolType type = convertType((yyvsp[-2].string));
        if (type == -1) {
            fprintf(stderr, "Error: Invalid type '%s' at line %d\n", (yyvsp[-2].string), yylineno);
            YYABORT;
        }
        
        // Check if variable already exists in current scope
        Symbol* existing = lookupSymbol(symbolTable, (yyvsp[-1].string));
        if (existing && existing->scope_level == symbolTable->current_scope) {
            fprintf(stderr, "Error: Variable '%s' already declared in current scope at line %d\n", 
                    (yyvsp[-1].string), yylineno);
            YYABORT;
        }

        // Try to insert the symbol
        if (!insertSymbol(symbolTable, (yyvsp[-1].string), type, false)) {
            fprintf(stderr, "Error: Failed to insert variable '%s' into symbol table at line %d\n", 
                    (yyvsp[-1].string), yylineno);
            YYABORT;
        }

        // Print debug information for successful insertion
        printf("Debug: Successfully inserted variable %s of type %s into symbol table at scope %d\n", 
               (yyvsp[-1].string), (yyvsp[-2].string), symbolTable->current_scope);
        
        // Verify the insertion by looking up the symbol
        Symbol* verifySymbol = lookupSymbol(symbolTable, (yyvsp[-1].string));
        if (verifySymbol) {
            printf("Debug: Verified symbol %s exists in table with type %s at scope %d\n",
                   verifySymbol->name, getTypeString(verifySymbol->type), verifySymbol->scope_level);
        } else {
            fprintf(stderr, "Warning: Symbol %s was not found after insertion\n", (yyvsp[-1].string));
        }
    }
#line 1760 "parser.tab.c"
    break;

  case 26: /* Assignment: ID EQ Expression SEMICOLON  */
#line 590 "parser.y"
    {
        (yyval.ast) = createNode(NODE_ASSIGNMENT, (yyvsp[-3].string));
        addChild((yyval.ast), (yyvsp[-1].ast));

        // Lookup the variable in the symbol table
        Symbol* sym = lookupSymbol(symbolTable, (yyvsp[-3].string));
        if (!sym) {
            fprintf(stderr, "Error: Undefined variable '%s' at line %d\n", (yyvsp[-3].string), yylineno);
            YYABORT;
        }

        // Mark the variable as initialized
        sym->initialized = true;
        printf("Debug: Marked variable %s as initialized\n", (yyvsp[-3].string));
    }
#line 1780 "parser.tab.c"
    break;

  case 27: /* ArrayDeclaration: TYPE LBRACKET INT_NUMBER RBRACKET ID SEMICOLON  */
#line 609 "parser.y"
    {
        (yyval.ast) = createNode(NODE_ARRAY_DECLARATION, (yyvsp[-1].string));
        ASTNode* typeNode = createNode(NODE_TYPE, (yyvsp[-5].string));
        char numStr[20];
        sprintf(numStr, "%d", (yyvsp[-3].int_val));
        ASTNode* sizeNode = createNode(NODE_NUMBER, numStr);
        addChild((yyval.ast), typeNode);
        addChild((yyval.ast), sizeNode);

        // Check if array already exists in current scope
        Symbol* existing = lookupSymbol(symbolTable, (yyvsp[-1].string));
        if (existing && existing->scope_level == symbolTable->current_scope) {
            fprintf(stderr, "Error: Array '%s' already declared in current scope at line %d\n", 
                    (yyvsp[-1].string), yylineno);
            YYABORT;
        }

        // Add array to symbol table
        SymbolType elemType = convertType((yyvsp[-5].string));
        if (elemType == -1) {
            fprintf(stderr, "Error: Invalid type '%s' for array at line %d\n", (yyvsp[-5].string), yylineno);
            YYABORT;
        }

        if (!insertArraySymbol(symbolTable, (yyvsp[-1].string), elemType, (yyvsp[-3].int_val))) {
            fprintf(stderr, "Error: Failed to insert array '%s' into symbol table at line %d\n", 
                    (yyvsp[-1].string), yylineno);
            YYABORT;
        }
        printf("Debug: Inserted array %s of type %s[%d] into symbol table\n", (yyvsp[-1].string), (yyvsp[-5].string), (yyvsp[-3].int_val));
    }
#line 1816 "parser.tab.c"
    break;

  case 28: /* ArrayAssignment: ID LBRACKET INT_NUMBER RBRACKET EQ Expression SEMICOLON  */
#line 644 "parser.y"
    {
        (yyval.ast) = createNode(NODE_ARRAY_ASSIGNMENT, (yyvsp[-6].string));
        char numStr[20];
        sprintf(numStr, "%d", (yyvsp[-4].int_val));
        ASTNode* indexNode = createNode(NODE_NUMBER, numStr);
        addChild((yyval.ast), indexNode);
        addChild((yyval.ast), (yyvsp[-1].ast));

        // Verify array exists and index is within bounds
        Symbol* sym = lookupSymbol(symbolTable, (yyvsp[-6].string));
        if (!sym || sym->type != TYPE_ARRAY) {
            fprintf(stderr, "Error: Undefined array '%s' at line %d\n", (yyvsp[-6].string), yylineno);
            YYABORT;
        }
        if ((yyvsp[-4].int_val) >= sym->array_info.size) {
            fprintf(stderr, "Error: Array index out of bounds at line %d\n", yylineno);
            YYABORT;
        }
    }
#line 1840 "parser.tab.c"
    break;

  case 29: /* ReturnStatement: RETURN Expression SEMICOLON  */
#line 667 "parser.y"
    {
        (yyval.ast) = createNode(NODE_RETURN_STATEMENT, NULL);
        addChild((yyval.ast), (yyvsp[-1].ast));
    }
#line 1849 "parser.tab.c"
    break;

  case 30: /* ReturnStatement: %empty  */
#line 672 "parser.y"
    {
        (yyval.ast) = createNode(NODE_RETURN_STATEMENT, NULL);
    }
#line 1857 "parser.tab.c"
    break;

  case 31: /* Expression: Expression PLUS Term  */
#line 679 "parser.y"
    {
        (yyval.ast) = createNode(NODE_EXPRESSION, "+");
        addChild((yyval.ast), (yyvsp[-2].ast));
        addChild((yyval.ast), (yyvsp[0].ast));
    }
#line 1867 "parser.tab.c"
    break;

  case 32: /* Expression: Expression SUB Term  */
#line 685 "parser.y"
    {
        (yyval.ast) = createNode(NODE_EXPRESSION, "-");
        addChild((yyval.ast), (yyvsp[-2].ast));
        addChild((yyval.ast), (yyvsp[0].ast));
    }
#line 1877 "parser.tab.c"
    break;

  case 33: /* Expression: Term  */
#line 691 "parser.y"
    {
        (yyval.ast) = (yyvsp[0].ast);
    }
#line 1885 "parser.tab.c"
    break;

  case 34: /* Term: Term MULTIPLY Factor  */
#line 698 "parser.y"
    {
        (yyval.ast) = createNode(NODE_TERM, "*");
        addChild((yyval.ast), (yyvsp[-2].ast));
        addChild((yyval.ast), (yyvsp[0].ast));
    }
#line 1895 "parser.tab.c"
    break;

  case 35: /* Term: Term DIV Factor  */
#line 704 "parser.y"
    {
        (yyval.ast) = createNode(NODE_TERM, "/");
        addChild((yyval.ast), (yyvsp[-2].ast));
        addChild((yyval.ast), (yyvsp[0].ast));
    }
#line 1905 "parser.tab.c"
    break;

  case 36: /* Term: Factor  */
#line 710 "parser.y"
    {
        (yyval.ast) = (yyvsp[0].ast);
    }
#line 1913 "parser.tab.c"
    break;

  case 37: /* Factor: INT_NUMBER  */
#line 717 "parser.y"
    {
        char numStr[20];
        sprintf(numStr, "%d", (yyvsp[0].int_val));
        (yyval.ast) = createNode(NODE_INT_NUMBER, numStr);
    }
#line 1923 "parser.tab.c"
    break;

  case 38: /* Factor: FLOAT_NUMBER  */
#line 723 "parser.y"
    {
        char numStr[20];
        sprintf(numStr, "%.6f", (yyvsp[0].float_val));
        (yyval.ast) = createNode(NODE_FLOAT_NUMBER, numStr);
    }
#line 1933 "parser.tab.c"
    break;

  case 39: /* Factor: ID  */
#line 729 "parser.y"
    {
        (yyval.ast) = createNode(NODE_ID, (yyvsp[0].string));
        // Verify variable exists
        Symbol* sym = lookupSymbol(symbolTable, (yyvsp[0].string));
        if (!sym) {
            fprintf(stderr, "Error: Undefined variable '%s' at line %d\n", (yyvsp[0].string), yylineno);
            YYABORT;
        }
        if (!sym->initialized && sym->type != TYPE_FUNCTION) {
            fprintf(stderr, "Warning: Using uninitialized variable '%s' at line %d\n", 
                    (yyvsp[0].string), yylineno);
        }
    }
#line 1951 "parser.tab.c"
    break;

  case 40: /* Factor: ID LPAREN ArgList RPAREN  */
#line 743 "parser.y"
    {
        (yyval.ast) = createNode(NODE_FUNCTION_CALL, (yyvsp[-3].string));
        addChild((yyval.ast), (yyvsp[-1].ast));
        // Verify function exists and argument types match
        if (!verifyFunctionArgs((yyvsp[-3].string), (yyvsp[-1].ast))) {
            YYABORT;
        }
    }
#line 1964 "parser.tab.c"
    break;

  case 41: /* Factor: LPAREN Expression RPAREN  */
#line 752 "parser.y"
    {
        (yyval.ast) = (yyvsp[-1].ast);
    }
#line 1972 "parser.tab.c"
    break;

  case 42: /* ArgList: %empty  */
#line 759 "parser.y"
    {
        (yyval.ast) = createNode(NODE_ARG_LIST, NULL);
    }
#line 1980 "parser.tab.c"
    break;

  case 43: /* ArgList: Expression  */
#line 763 "parser.y"
    {
        (yyval.ast) = createNode(NODE_ARG_LIST, NULL);
        addChild((yyval.ast), (yyvsp[0].ast));
    }
#line 1989 "parser.tab.c"
    break;

  case 44: /* ArgList: Expression COMMA ArgList  */
#line 768 "parser.y"
    {
        (yyval.ast) = (yyvsp[0].ast);
        addChild((yyval.ast), (yyvsp[-2].ast));
    }
#line 1998 "parser.tab.c"
    break;


#line 2002 "parser.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 774 "parser.y"

int main(int argc, char *argv[]) {
    printf("Starting parsing process...\n");

    if (yyparse() == 0) {
        printf("Parsing completed successfully.\n");
        printf("\nPerforming semantic analysis...\n");
        semanticAnalysis(ast_root);
        
        if (hasSemanticErrors()) {
            printf("Compilation failed due to semantic errors.\n");
            return 1;
        }
        
        printf("\nSemantic Analysis Complete\n");
        printf("\nFinal Symbol Table Contents:\n");
        printSymbolTable(symbolTable);
        printf("\nAbstract Syntax Tree:\n");
        printAST(ast_root, 0);
        
        printf("\nGenerating Three Address Code:\n");
        TACList* tacList = createTAC(ast_root);
        printTAC(tacList);
        freeTAC(tacList);
    } else {
        printf("Parsing failed.\n");
    }

    // Cleanup
    if (ast_root) freeAST(ast_root);
    if (symbolTable) destroyTable(symbolTable);
    
    return 0;
}

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s at line %d\n", s, yylineno);
}
