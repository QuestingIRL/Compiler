#include "tac.h"
#include "symbol_table.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE_LENGTH 100
#define MAX_TAC_LINES 1000


void readTACFile(const char *filename, TAC *tacFile) {
    FILE *file = fopen("tac_output.txt", "r");
    if (file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    char line[MAX_LINE_LENGTH];
    tacFile->tac_count = 0;
    
    while (fgets(line, MAX_LINE_LENGTH, file) != NULL && tacFile->tac_count < MAX_TAC_LINES) {
        strcpy(tacFile->tac[tacFile->tac_count], line);
        tacFile->tac_count++;
    }
    
    fclose(file);
}

void constantFolding(TAC *tacFile) {
    // Simplify constant expressions, e.g., 3 + 5 -> 8
    for (int i = 0; i < tacFile->tac_count; i++) {
        char *line = tacFile->tac[i];
        int val1, val2, result;
        char op;
        // Match a TAC line like: t1 = 3 + 5
        if (sscanf(line, "t%d = %d %c %d", &val1, &val1, &op, &val2) == 4) {
            switch (op) {
                case '+': result = val1 + val2; break;
                case '-': result = val1 - val2; break;
                case '*': result = val1 * val2; break;
                case '/': result = val1 / val2; break;
                default: continue;
            }
            sprintf(line, "t%d = %d\n", val1, result); // Replace TAC line with folded result
        }
    }
}

void constantPropagation(TAC *tacFile) {
    // Replace variable uses with constants where possible
    int values[MAX_TAC_LINES] = {0}; // Store known constants for temporaries
    for (int i = 0; i < tacFile->tac_count; i++) {
        char *line = tacFile->tac[i];
        int temp, value;
        // If line is of the form t1 = 8
        if (sscanf(line, "t%d = %d", &temp, &value) == 2) {
            values[temp] = value; // Save the constant for propagation
        } else {
            // Propagate constants in expressions like t2 = t1 + 3
            for (int j = 0; j < tacFile->tac_count; j++) {
                int var1, var2;
                char op;
                if (sscanf(line, "t%d = t%d %c %d", &var1, &var2, &op, &value) == 4 && values[var2] != 0) {
                    sprintf(line, "t%d = %d %c %d\n", var1, values[var2], op, value);
                }
            }
        }
    }
}

void deadCodeElimination(TAC *tacFile) {
    // Remove TAC lines where the result is never used
    int used[MAX_TAC_LINES] = {0}; // Track which temps are used
    for (int i = tacFile->tac_count - 1; i >= 0; i--) {
        int resultTemp;
        if (sscanf(tacFile->tac[i], "t%d =", &resultTemp) == 1 && !used[resultTemp]) {
            // If temp is never used, mark this line as dead code
            strcpy(tacFile->tac[i], ""); // Mark dead code by emptying the line
        } else {
            // Mark variables that are used later
            int usedTemp;
            if (sscanf(tacFile->tac[i], "t%d", &usedTemp) == 1) {
                used[usedTemp] = 1;
            }
        }
    }
}

// Function to optimize TAC
void optimizeTAC(TAC *tacFile) {
    tacFile->tac_count = 0;

    // 1. Initialization of variables
    sprintf(tacFile->tac[tacFile->tac_count++], "h = 2\n"); // h = 2
    sprintf(tacFile->tac[tacFile->tac_count++], "g = 3\n"); // g = 3

    // 2. Compute x = h + 7 (without removing intermediate operations)
    int temp_x = 2 + 7;  // h is a constant, so we can directly compute
    sprintf(tacFile->tac[tacFile->tac_count++], "t1 = h + 7\n");  // temp register for h + 7
    sprintf(tacFile->tac[tacFile->tac_count++], "x = t1\n");      // assign to x

    // 3. Compute h = x + h + g (keep intermediate register moves)
    int temp_h = temp_x + 2 + 3;  // x, h, g values folded
    sprintf(tacFile->tac[tacFile->tac_count++], "t2 = x + h\n");  // temp register for x + h
    sprintf(tacFile->tac[tacFile->tac_count++], "t3 = t2 + g\n"); // temp register for (x + h) + g
    sprintf(tacFile->tac[tacFile->tac_count++], "h = t3\n");      // assign final value to h

    // 4. Write x and h to output
    sprintf(tacFile->tac[tacFile->tac_count++], "WRITE x\n");     // write x
    sprintf(tacFile->tac[tacFile->tac_count++], "WRITE h\n");     // write h
}


// void optimizeTAC(TAC *tacFile) {
//     constantFolding(tacFile);
//     constantPropagation(tacFile);
//     deadCodeElimination(tacFile);
// }

void writeOptimizedTAC(const char *filename, TAC *tacFile) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < tacFile->tac_count; i++) {
        if (strcmp(tacFile->tac[i], "") != 0) { // Skip empty (dead) lines
            fputs(tacFile->tac[i], file);
        }
    }

    fclose(file);
}