#ifndef TAC_H
#define TAC_H

#include "symbol_table.h"

#define MAX_LINE_LENGTH 100
#define MAX_TAC_LINES 1000

typedef struct {
    char tac[MAX_TAC_LINES][MAX_LINE_LENGTH]; // Store all TAC lines
    int tac_count;
} TAC;

void readTACFile(const char *filename, TAC *tacFile);
void constantFolding(TAC *tacFile);
void constantPropogation(TAC *tacFile);
void deadCodeElimination(TAC *tacFile);
void optimizeTAC(TAC *tacFile);
void writeOptimizedTAC(const char *filename, TAC *tacFile);

#endif