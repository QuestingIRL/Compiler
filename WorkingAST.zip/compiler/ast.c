#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

// Function to create a new AST node
ASTNode* createNode(NodeType type, char* value) {
    ASTNode* node = (ASTNode*) malloc(sizeof(ASTNode));
    node->type = type;
    node->value = value ? strdup(value) : NULL;
    node->numValue = 0;
    node->children = NULL;
    node->childCount = 0;
    return node;
}

// Function to add a child node to a parent node
void addChild(ASTNode* parent, ASTNode* child) {
    parent->children = realloc(parent->children, sizeof(ASTNode*) * (parent->childCount + 1));
    parent->children[parent->childCount++] = child;
}

// Helper function to print indentation
void printIndent(int indent) {
    for (int i = 0; i < indent; i++) {
        printf("  ");
    }
}

// Function to print the AST in a readable format
void printAST(ASTNode* node, int indent) {
    if (node == NULL) return;

    printIndent(indent);
    switch (node->type) {
        case NODE_PROGRAM:
            printf("Program\n");
            break;
        case NODE_MAIN_FUNCTION:
            printf("MainFunction\n");
            break;
        case NODE_FUNCTION_LIST:
            printf("FunctionList\n");
            break;
        case NODE_FUNCTION:
            printf("Function: %s\n", node->value);
            break;
        case NODE_PARAM_LIST:
            printf("ParamList\n");
            break;
        case NODE_PARAM:
            printf("Param: %s\n", node->value);
            break;
        case NODE_STATEMENT_LIST:
            printf("StatementList\n");
            break;
        case NODE_STATEMENT:
            printf("Statement\n");
            break;
        case NODE_VAR_DECLARATION:
            printf("VarDeclaration: %s\n", node->value);
            break;
        case NODE_ASSIGNMENT:
            printf("Assignment to %s\n", node->value);
            break;
        case NODE_ARRAY_DECLARATION:
            printf("ArrayDeclaration: %s\n", node->value);
            break;
        case NODE_ARRAY_ASSIGNMENT:
            printf("ArrayAssignment: %s\n", node->value);
            break;
        case NODE_RETURN_STATEMENT:
            printf("ReturnStatement\n");
            break;
        case NODE_EXPRESSION:
            printf("Expression\n");
            break;
        case NODE_TERM:
            printf("Term\n");
            break;
        case NODE_FACTOR:
            printf("Factor: %s\n", node->value);
            break;
        case NODE_ARG_LIST:
            printf("ArgList\n");
            break;
        case NODE_TYPE:
            printf("Type: %s\n", node->value);
            break;
        case NODE_ID:
            printf("Identifier: %s\n", node->value);
            break;
        case NODE_NUMBER:
            printf("Number: %s\n", node->value);
            break;
        case NODE_OPERATOR:
            printf("Operator: %s\n", node->value);
            break;
        default:
            printf("Unknown node type\n");
            break;
    }

    // Recursively print child nodes
    for (int i = 0; i < node->childCount; i++) {
        printAST(node->children[i], indent + 1);
    }
}

// Function to free the memory allocated for the AST
void freeAST(ASTNode* node) {
    if (node == NULL) return;

    if (node->value) free(node->value);
    for (int i = 0; i < node->childCount; i++) {
        freeAST(node->children[i]);
    }
    if (node->children) free(node->children);
    free(node);
}
