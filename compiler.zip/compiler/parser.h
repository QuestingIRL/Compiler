#ifndef PARSER_H
#define PARSER_H

/* Token definitions */
enum yytokentype {
    TYPE = 258,
    ID,
    NUMBER,
    SEMICOLON,
    COMMA,
    EQ,
    PLUS,
    SUB,
    MULTIPLY,
    DIV,
    LPAREN,
    RPAREN,
    LBRACE,
    RBRACE,
    LBRACKET,
    RBRACKET,
    RETURN,
    FUNCTION
};

/* Value type */
typedef union {
    char* string;
    int number;
} YYSTYPE;

extern YYSTYPE yylval;

#endif /* PARSER_H */
