#include <stdio.h>

/* Declare yyparse */
int yyparse();

int main(int argc, char *argv[]) {
    printf("Starting the parser...\n");
    if (yyparse() == 0) {
        printf("Parsing completed successfully.\n");
    } else {
        printf("Parsing failed.\n");
    }
    return 0;
}
