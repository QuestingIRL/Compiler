package main

import (
	"fmt"
	"majesticlang-compiler/lexer"
	"majesticlang-compiler/parser"
	"majesticlang-compiler/ast"
)

func main() {
	input := `
		int x;
		int y;
		int z;
		x = 10;
		y = 3;
		z = x + y;
		write z;

	`

	// Initialize and run the lexer
	fmt.Println("Lexer is running...")
	l := lexer.New(input)

	// Initialize and run the parser
	fmt.Println("Parser is running...")
	p := parser.New(l)

	// Parse the program and build the AST
	program := p.ParseProgram()

	// Check for parser errors
	if len(p.Errors()) > 0 {
		fmt.Println("Parser errors:")
		for _, msg := range p.Errors() {
			fmt.Println(msg)
		}
		return
	}

	// Display the AST
	fmt.Println("\nAbstract Syntax Tree (AST):")
	printNode(program, "")
}

// printNode prints the AST node in a tree-like structure.
func printNode(node interface{}, prefix string) {
	switch n := node.(type) {
	case *ast.Program:
		fmt.Println(prefix + "PROGRAM")
		for i, stmt := range n.Statements {
			if i == len(n.Statements)-1 {
				printNode(stmt, prefix+"└── ")
			} else {
				printNode(stmt, prefix+"├── ")
			}
		}
	case *ast.DeclarationStatement:
		fmt.Printf("%sVAR_DECL (%s)\n", prefix, n.Name.Value)
		printNode(&ast.Identifier{Token: n.Token, Value: n.Token.Literal}, prefix+"│   └── ")
		if n.Value != nil {
			printNode(n.Value, prefix+"│   └── ")
		}
	case *ast.AssignmentStatement:
		fmt.Printf("%sASSIGN (%s)\n", prefix, n.Name.Value)
		printNode(n.Value, prefix+"│   └── ")
	case *ast.WriteStatement:
		fmt.Printf("%sWRITE\n", prefix)
		printNode(n.Value, prefix+"│   └── ")
	case *ast.Identifier:
		fmt.Printf("%sID (%s)\n", prefix, n.Value)
	case *ast.LiteralExpression:
		fmt.Printf("%s%s (%s)\n", prefix, n.Token.Type, n.Value)
	case *ast.BinaryExpression:
		fmt.Printf("%sEXPR (%s)\n", prefix, n.Token.Literal)
		printNode(n.Left, prefix+"│   ├── ")
		printNode(n.Right, prefix+"│   └── ")
	default:
		fmt.Printf("%sUNKNOWN NODE (%+v)\n", prefix, n)
	}
}

