package ast

import (
	"majesticlang-compiler/token"
)

// Node represents a node in the AST.
type Node interface {
	TokenLiteral() string
}

// Statement represents a statement in the language.
type Statement interface {
	Node
	statementNode()
}

// Expression represents an expression in the language.
type Expression interface {
	Node
	expressionNode()
}

// Program is the root of the AST.
type Program struct {
	Statements []Statement
}

func (p *Program) TokenLiteral() string {
	if len(p.Statements) > 0 {
		return p.Statements[0].TokenLiteral()
	}
	return ""
}

// Identifier represents variable or function names.
type Identifier struct {
	Token token.Token // The IDENT token
	Value string      // The name of the identifier
}

func (i *Identifier) expressionNode() {}
func (i *Identifier) TokenLiteral() string {
	return i.Token.Literal
}

// DeclarationStatement represents a variable declaration.
type DeclarationStatement struct {
	Token token.Token // The token for the type (e.g., "int")
	Name  *Identifier // The variable name
	Value Expression  // The value assigned to the variable
}

func (ds *DeclarationStatement) statementNode() {}
func (ds *DeclarationStatement) TokenLiteral() string {
	return ds.Token.Literal
}

// AssignmentStatement represents a variable assignment.
type AssignmentStatement struct {
	Token token.Token // The token for the identifier
	Name  *Identifier // The variable name
	Value Expression  // The value being assigned
}

func (as *AssignmentStatement) statementNode() {}
func (as *AssignmentStatement) TokenLiteral() string {
	return as.Token.Literal
}

// WriteStatement represents a write statement.
type WriteStatement struct {
	Token token.Token // The WRITE token
	Value Expression  // The expression to write
}

func (ws *WriteStatement) statementNode() {}
func (ws *WriteStatement) TokenLiteral() string {
	return ws.Token.Literal
}

// LiteralExpression represents literal values like integers, floats, etc.
type LiteralExpression struct {
	Token token.Token // The token for the literal
	Value string      // The literal value
}

func (le *LiteralExpression) expressionNode() {}
func (le *LiteralExpression) TokenLiteral() string {
	return le.Token.Literal
}

// BinaryExpression represents a binary operation (e.g., x + y).
type BinaryExpression struct {
	Token    token.Token  // The operator token (e.g., "+")
	Left     Expression   // The left-hand side of the operation
	Right    Expression   // The right-hand side of the operation
}

func (be *BinaryExpression) expressionNode() {}
func (be *BinaryExpression) TokenLiteral() string {
	return be.Token.Literal
}
