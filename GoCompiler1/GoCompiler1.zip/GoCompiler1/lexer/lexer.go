package lexer

import (
	"majesticlang-compiler/token"
	"unicode"
	"fmt"
)

// Lexer holds the state of the lexer.
type Lexer struct {
	input        string
	position     int // current position in input (points to current char)
	readPosition int // current reading position in input (after current char)
	ch           byte // current char under examination
}

// New initializes a new lexer.
func New(input string) *Lexer {
	l := &Lexer{input: input}
	l.readChar()
	return l
}

// readChar advances to the next character in the input.
func (l *Lexer) readChar() {
	if l.readPosition >= len(l.input) {
		l.ch = 0 // ASCII for NUL, signifying EOF
	} else {
		l.ch = l.input[l.readPosition]
	}
	l.position = l.readPosition
	l.readPosition++
}

// NextToken analyzes the next token and returns it.
func (l *Lexer) NextToken() token.Token {
	l.skipWhitespace()

	switch l.ch {
	case '+':
		return l.newToken(token.PLUS, string(l.ch))
	case '-':
		return l.newToken(token.MINUS, string(l.ch))
	case '*':
		return l.newToken(token.ASTERISK, string(l.ch))
	case '/':
		return l.newToken(token.SLASH, string(l.ch))
	case '<':
		return l.readTwoCharOperator(token.LT, token.LE, "=")
	case '>':
		return l.readTwoCharOperator(token.GT, token.GE, "=")
	case '=':
		return l.readTwoCharOperator(token.ASSIGN, token.EQ, "=")
	case '!':
		return l.readTwoCharOperator(token.ILLEGAL, token.NOT_EQ, "=")
	case '&':
		return l.readTwoCharOperator(token.ILLEGAL, token.AND, "&")
	case '|':
		return l.readTwoCharOperator(token.ILLEGAL, token.OR, "|")
	case '(':
		return l.newToken(token.LPAREN, string(l.ch))
	case ')':
		return l.newToken(token.RPAREN, string(l.ch))
	case '{':
		return l.newToken(token.LBRACE, string(l.ch))
	case '}':
		return l.newToken(token.RBRACE, string(l.ch))
	case '[':
		return l.newToken(token.LBRACKET, string(l.ch))
	case ']':
		return l.newToken(token.RBRACKET, string(l.ch))
	case ';':
		return l.newToken(token.SEMICOLON, string(l.ch))
	case ',':
		return l.newToken(token.COMMA, string(l.ch))
	case '\'':
		return l.readCharLiteral()
	case 0:
		return token.Token{Type: token.EOF, Literal: ""}
	default:
		if unicode.IsLetter(rune(l.ch)) {
			return l.readIdentifierOrKeyword()
		} else if unicode.IsDigit(rune(l.ch)) {
			return l.readNumber()
		} else {
			return l.newToken(token.ILLEGAL, string(l.ch))
		}
	}
}

// newToken creates a new token of the given type and literal.
func (l *Lexer) newToken(tokenType token.TokenType, literal string) token.Token {
	tok := token.Token{Type: tokenType, Literal: literal}
	l.readChar()
	return tok
}

// skipWhitespace skips over spaces, tabs, and newlines.
func (l *Lexer) skipWhitespace() {
	for l.ch == ' ' || l.ch == '\t' || l.ch == '\n' || l.ch == '\r' {
		l.readChar()
	}
}

// readTwoCharOperator handles two-character operators like ==, !=, etc.
func (l *Lexer) readTwoCharOperator(single token.TokenType, compound token.TokenType, nextChar string) token.Token {
	literal := string(l.ch)
	if l.peekChar() == nextChar[0] {
		l.readChar()
		literal += string(l.ch)
		l.readChar()
		return token.Token{Type: compound, Literal: literal}
	}
	l.readChar()
	return token.Token{Type: single, Literal: literal}
}

// peekChar returns the next character without advancing the position.
func (l *Lexer) peekChar() byte {
	if l.readPosition >= len(l.input) {
		return 0
	}
	return l.input[l.readPosition]
}

// readIdentifierOrKeyword reads identifiers and checks for keywords.
func (l *Lexer) readIdentifierOrKeyword() token.Token {
	position := l.position
	for unicode.IsLetter(rune(l.ch)) || unicode.IsDigit(rune(l.ch)) || l.ch == '_' {
		l.readChar()
	}
	literal := l.input[position:l.position]
	tokenType := token.LookupIdent(literal)
	return token.Token{Type: tokenType, Literal: literal}
}

// readNumber handles integer and floating-point literals.
func (l *Lexer) readNumber() token.Token {
	position := l.position
	for unicode.IsDigit(rune(l.ch)) {
		l.readChar()
	}
	if l.ch == '.' {
		l.readChar()
		for unicode.IsDigit(rune(l.ch)) {
			l.readChar()
		}
		return token.Token{Type: token.FLOAT, Literal: l.input[position:l.position]}
	}
	return token.Token{Type: token.INT, Literal: l.input[position:l.position]}
}

// readCharLiteral handles character literals like 'a'.
func (l *Lexer) readCharLiteral() token.Token {
	l.readChar() // Skip opening quote
	char := l.ch
	l.readChar() // Skip the character
	if l.ch != '\'' {
		return token.Token{Type: token.ILLEGAL, Literal: fmt.Sprintf("Invalid char literal: %c", char)}
	}
	l.readChar() // Skip closing quote
	return token.Token{Type: token.CHAR, Literal: string(char)}
}
