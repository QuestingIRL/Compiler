package token

// TokenType represents the type of a token.
type TokenType string

// Token represents a single token.
type Token struct {
	Type    TokenType
	Literal string
}

// TokenType constants.
const (
	ILLEGAL = "ILLEGAL"
	EOF     = "EOF"

	// Identifiers + literals
	IDENT  = "IDENT"  // e.g., variable names
	INT    = "INT"    // Integer literals
	FLOAT  = "FLOAT"  // Float literals
	CHAR   = "CHAR"   // Character literals
	BOOLEAN = "BOOLEAN" // Boolean literals

	// Operators
	ASSIGN = "="
	PLUS   = "+"
	MINUS  = "-"
	ASTERISK = "*"
	SLASH  = "/"

	LT     = "<"
	GT     = ">"
	EQ     = "=="
	NOT_EQ = "!="
	LE     = "<="
	GE     = ">="
	AND    = "&&"
	OR     = "||"

	// Delimiters
	COMMA     = ","
	SEMICOLON = ";"
	LPAREN    = "("
	RPAREN    = ")"
	LBRACE    = "{"
	RBRACE    = "}"
	LBRACKET  = "["
	RBRACKET  = "]"

	// Keywords
	FUNC   = "FUNC"
	RETURN = "RETURN"
	INT_KW = "INT"
	FLOAT_KW = "FLOAT"
	BOOL_KW = "BOOL"
	CHAR_KW = "CHAR"
	WRITE  = "WRITE"
	TRUE   = "TRUE"
	FALSE  = "FALSE"
)

// Keywords maps keyword strings to token types.
var keywords = map[string]TokenType{
	"func":   FUNC,
	"return": RETURN,
	"int":    INT_KW,
	"float":  FLOAT_KW,
	"bool":   BOOL_KW,
	"char":   CHAR_KW,
	"write":  WRITE,
	"true":   TRUE,
	"false":  FALSE,
}

// LookupIdent checks if an identifier is a keyword, otherwise returns IDENT.
func LookupIdent(ident string) TokenType {
	if tok, ok := keywords[ident]; ok {
		return tok
	}
	return IDENT
}
