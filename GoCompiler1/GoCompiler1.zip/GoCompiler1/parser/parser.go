package parser

import (
	"fmt"
	"majesticlang-compiler/ast"
	"majesticlang-compiler/lexer"
	"majesticlang-compiler/token"
)

type Parser struct {
	l         *lexer.Lexer
	errors    []string
	curToken  token.Token
	peekToken token.Token
}

// New creates a new parser instance.
func New(l *lexer.Lexer) *Parser {
	p := &Parser{
		l:      l,
		errors: []string{},
	}
	p.nextToken()
	p.nextToken()
	return p
}

func (p *Parser) nextToken() {
	p.curToken = p.peekToken
	p.peekToken = p.l.NextToken()
}

func (p *Parser) Errors() []string {
	return p.errors
}

func (p *Parser) ParseProgram() *ast.Program {
	program := &ast.Program{}
	program.Statements = []ast.Statement{}

	for p.curToken.Type != token.EOF {
		stmt := p.parseStatement()
		if stmt != nil {
			program.Statements = append(program.Statements, stmt)
		}
		p.skipSemicolon()
	}
	return program
}

func (p *Parser) parseStatement() ast.Statement {
	switch p.curToken.Type {
	case token.INT_KW, token.FLOAT_KW, token.BOOL_KW, token.CHAR_KW:
		return p.parseDeclaration()
	case token.IDENT:
		return p.parseAssignment()
	case token.WRITE:
		return p.parseWriteStatement()
	default:
		p.unexpectedTokenError("statement")
		return nil
	}
}

func (p *Parser) parseDeclaration() *ast.DeclarationStatement {
	stmt := &ast.DeclarationStatement{
		Token: p.curToken,
	}
	p.nextToken()

	if p.curToken.Type != token.IDENT {
		p.errors = append(p.errors, "Expected identifier after type declaration")
		return nil
	}

	stmt.Name = &ast.Identifier{
		Token: p.curToken,
		Value: p.curToken.Literal,
	}

	p.nextToken()
	if p.curToken.Type == token.ASSIGN {
		p.nextToken()
		stmt.Value = p.parseExpression()
	}
	return stmt
}

func (p *Parser) parseAssignment() *ast.AssignmentStatement {
	stmt := &ast.AssignmentStatement{
		Token: p.curToken,
		Name: &ast.Identifier{
			Token: p.curToken,
			Value: p.curToken.Literal,
		},
	}

	p.nextToken()
	if p.curToken.Type != token.ASSIGN {
		p.errors = append(p.errors, "Expected '=' after identifier in assignment")
		return nil
	}

	p.nextToken()
	stmt.Value = p.parseExpression()
	return stmt
}

func (p *Parser) parseWriteStatement() *ast.WriteStatement {
	stmt := &ast.WriteStatement{
		Token: p.curToken,
	}

	p.nextToken()
	stmt.Value = p.parseExpression()
	return stmt
}

func (p *Parser) parseExpression() ast.Expression {
	return p.parseBinaryExpression()
}

func (p *Parser) parseBinaryExpression() ast.Expression {
	left := p.parsePrimaryExpression()

	for p.curToken.Type == token.PLUS || p.curToken.Type == token.MINUS || p.curToken.Type == token.ASTERISK || p.curToken.Type == token.SLASH {
		op := p.curToken
		p.nextToken()
		right := p.parsePrimaryExpression()
		left = &ast.BinaryExpression{
			Token: op,
			Left:  left,
			Right: right,
		}
	}
	return left
}

func (p *Parser) parsePrimaryExpression() ast.Expression {
	switch p.curToken.Type {
	case token.IDENT:
		expr := &ast.Identifier{Token: p.curToken, Value: p.curToken.Literal}
		p.nextToken()
		return expr
	case token.INT, token.FLOAT:
		expr := &ast.LiteralExpression{Token: p.curToken, Value: p.curToken.Literal}
		p.nextToken()
		return expr
	default:
		p.unexpectedTokenError("primary expression")
		return nil
	}
}

func (p *Parser) skipSemicolon() {
	if p.curToken.Type == token.SEMICOLON {
		p.nextToken()
	} else {
		p.errors = append(p.errors, fmt.Sprintf("Expected ';' but got %s", p.curToken.Literal))
	}
}

func (p *Parser) unexpectedTokenError(context string) {
	errorMsg := fmt.Sprintf("Unexpected token %s in %s", p.curToken.Literal, context)
	p.errors = append(p.errors, errorMsg)
	p.nextToken()
}
