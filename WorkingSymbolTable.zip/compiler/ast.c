#include "ast.h"
#include <stdlib.h>
#include <string.h>

#define INITIAL_CAPACITY 10
#define MAX_TREE_STRING 1000

// Helper function to get string representation of node type
const char* getNodeTypeString(NodeType type) {
    switch(type) {
        case NODE_PROGRAM: return "PROGRAM";
        case NODE_MAIN_FUNCTION: return "MAIN";
        case NODE_FUNCTION_LIST: return "FUNCTION_LIST";
        case NODE_FUNCTION: return "FUNCTION";
        case NODE_PARAM_LIST: return "PARAM_LIST";
        case NODE_PARAM: return "PARAM";
        case NODE_STATEMENT_LIST: return "STMT_LIST";
        case NODE_STATEMENT: return "STMT";
        case NODE_VAR_DECLARATION: return "VAR_DECL";
        case NODE_ASSIGNMENT: return "ASSIGN";
        case NODE_ARRAY_DECLARATION: return "ARRAY_DECL";
        case NODE_ARRAY_ASSIGNMENT: return "ARRAY_ASSIGN";
        case NODE_RETURN_STATEMENT: return "RETURN";
        case NODE_EXPRESSION: return "EXPR";
        case NODE_TERM: return "TERM";
        case NODE_FACTOR: return "FACTOR";
        case NODE_ARG_LIST: return "ARG_LIST";
        case NODE_TYPE: return "TYPE";
        case NODE_ID: return "ID";
        case NODE_NUMBER: return "NUMBER";
        case NODE_OPERATOR: return "OP";
        case NODE_WRITE_STATEMENT: return "WRITE";
        case NODE_INT_NUMBER: return "INT";
        case NODE_FLOAT_NUMBER: return "FLOAT";
        case NODE_FUNCTION_CALL: return "FUNC_CALL";
        default: return "UNKNOWN";
    }
}

ASTNode* createNode(NodeType type, char* value) {
    ASTNode* node = (ASTNode*)malloc(sizeof(ASTNode));
    if (!node) {
        fprintf(stderr, "Memory allocation failed!\n");
        exit(1);
    }
    
    node->type = type;
    node->value = value ? strdup(value) : NULL;
    node->children = (ASTNode**)malloc(INITIAL_CAPACITY * sizeof(ASTNode*));
    node->childCount = 0;
    node->level = 0;
    
    return node;
}

void addChild(ASTNode* parent, ASTNode* child) {
    if (!parent || !child) return;
    
    if (parent->childCount % INITIAL_CAPACITY == 0 && parent->childCount > 0) {
        ASTNode** newChildren = (ASTNode**)realloc(parent->children, 
            (parent->childCount + INITIAL_CAPACITY) * sizeof(ASTNode*));
        if (!newChildren) {
            fprintf(stderr, "Memory reallocation failed!\n");
            exit(1);
        }
        parent->children = newChildren;
    }
    
    child->level = parent->level + 1;
    parent->children[parent->childCount++] = child;
}

// Helper function to create the visual tree connection lines
void printTreeLines(int level, int* childrenLeft, int isLast) {
    for (int i = 0; i < level - 1; i++) {
        if (childrenLeft[i] > 0)
            printf("│   ");
        else
            printf("    ");
    }
    if (level > 0) {
        if (isLast)
            printf("└── ");
        else
            printf("├── ");
    }
}

void printAST(ASTNode* node, int level) {
    static int childrenLeft[100] = {0};  // Tracks remaining children at each level
    
    if (!node) return;
    
    // Print current node with proper tree structure
    printTreeLines(level, childrenLeft, level > 0 && childrenLeft[level-1] == 1);
    
    // Print node information
    printf("%s", getNodeTypeString(node->type));
    if (node->value) 
        printf(" (%s)", node->value);
    printf("\n");
    
    // Update children count for next level
    if (level > 0) 
        childrenLeft[level-1]--;
    
    // Set up for children
    if (node->childCount > 0) {
        childrenLeft[level] = node->childCount;
        
        // Print all children
        for (int i = 0; i < node->childCount; i++) {
            printAST(node->children[i], level + 1);
        }
    }
}

void freeAST(ASTNode* node) {
    if (!node) return;
    
    // Recursively free all children
    for (int i = 0; i < node->childCount; i++) {
        freeAST(node->children[i]);
    }
    
    // Free the current node's resources
    free(node->value);
    free(node->children);
    free(node);
}