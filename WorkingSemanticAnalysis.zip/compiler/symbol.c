#include "symbol.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

static bool inMain = false;

static int scopeCount = 0;

static char* functionNames[100];

static int i = 0;

void setInMain(bool value) {
    inMain = value;
}

bool isInMain() {
    return inMain;
}

void setScopeCount(int value){
    scopeCount++;
}

int checkScopeCount(){
    return scopeCount;
}

// Hash function for symbol names
static unsigned int hash(const char* name, int table_size) {
    unsigned int hash = 0;
    for (const char* p = name; *p != '\0'; p++) {
        hash = hash * 31 + *p;
    }
    return hash % table_size;
}



void pushScope(SymbolTable* table) {
    if (!table) return;
    
    ScopeNode* newScope = (ScopeNode*)malloc(sizeof(ScopeNode));
    if (!newScope) return;
    
    table->current_scope = checkScopeCount();
    newScope->scope_level = table->current_scope;
    newScope->next = table->scope_stack;
    table->scope_stack = newScope;
    
    printf("Debug: Pushed new scope %d\n", table->current_scope);
    setScopeCount(scopeCount);
}

void popScope(SymbolTable* table) {
    if (!table || !table->scope_stack) return;
    
    ScopeNode* oldScope = table->scope_stack;
    table->scope_stack = oldScope->next;
    table->current_scope = (table->scope_stack) ? table->scope_stack->scope_level : 0;
    
    free(oldScope);
    printf("Debug: Popped scope, current scope is now %d\n", table->current_scope);
}

SymbolTable* initializeTable(int size) {
    SymbolTable* table = (SymbolTable*)malloc(sizeof(SymbolTable));
    if (!table) return NULL;

    table->table = (Symbol**)calloc(size, sizeof(Symbol*));
    if (!table->table) {
        free(table);
        return NULL;
    }

    table->size = size;
    table->current_scope = 0;
    table->scope_stack = NULL;

    printf("\n\n hello \n\n");
    
    // Start with global scope (scope level 0)
    //pushScope(table);
    return table;
}

void destroyParameterList(ParameterList* params) {
    while (params) {
        ParameterList* next = params->next;
        free(params->name);
        free(params);
        params = next;
    }
}

void destroySymbol(Symbol* symbol) {
    if (!symbol) return;
    free(symbol->name);
    if (symbol->type == TYPE_FUNCTION) {
        destroyParameterList(symbol->function_info.params);
    }
    destroySymbol(symbol->next);
    free(symbol);
}

void destroyTable(SymbolTable* table) {
    if (!table) return;
    
    // Clean up the scope stack
    while (table->scope_stack) {
        ScopeNode* temp = table->scope_stack;
        table->scope_stack = table->scope_stack->next;
        free(temp);
    }
    
    // Clean up symbols
    for (int i = 0; i < table->size; i++) {
        destroySymbol(table->table[i]);
    }
    
    free(table->table);
    free(table);
}

bool insertSymbol(SymbolTable* table, const char* name, SymbolType type, bool initialized) {
    if (!table || !name) {
        printf("Debug: Insert failed - NULL table or name\n");
        return false;
    }

    unsigned int index = hash(name, table->size);
    printf("Debug: Inserting %s at hash index %u (table size %d)\n", 
           name, index, table->size);

    // Verify table entry exists
    if (!table->table) {
        printf("Debug: Insert failed - NULL table array\n");
        return false;
    }

    Symbol* new_symbol = (Symbol*)malloc(sizeof(Symbol));
    if (!new_symbol) {
        printf("Debug: Insert failed - malloc failed for new symbol\n");
        return false;
    }

    new_symbol->name = strdup(name);
    new_symbol->type = type;
    new_symbol->scope_level = inMain ? 0 : table->current_scope;
    new_symbol->initialized = initialized;
    new_symbol->next = table->table[index];
    table->table[index] = new_symbol;

    printf("Debug: Successfully inserted %s at index %u with scope %d\n", 
           name, index, table->current_scope);
    return true;
}

bool insertArraySymbol(SymbolTable* table, const char* name, SymbolType element_type, int size) {
    if (!table || !name || size <= 0) return false;

    unsigned int index = hash(name, table->size);
    Symbol* new_symbol = (Symbol*)malloc(sizeof(Symbol));
    if (!new_symbol) return false;

    new_symbol->name = strdup(name);
    new_symbol->type = TYPE_ARRAY;
    new_symbol->scope_level = inMain ? 0 : table->current_scope;
    new_symbol->initialized = false;
    new_symbol->array_info.element_type = element_type;
    new_symbol->array_info.size = size;
    new_symbol->next = table->table[index];
    table->table[index] = new_symbol;

    return true;
}

bool insertFunctionSymbol(SymbolTable* table, const char* name, SymbolType return_type, ParameterList* params) {
    if (!table || !name) return false;

    unsigned int index = hash(name, table->size);
    Symbol* new_symbol = (Symbol*)malloc(sizeof(Symbol));
    if (!new_symbol) return false;

    new_symbol->name = strdup(name);
    new_symbol->type = TYPE_FUNCTION;
    new_symbol->scope_level = table->current_scope;
    new_symbol->initialized = true;
    new_symbol->function_info.return_type = return_type;
    new_symbol->function_info.params = params;
    new_symbol->next = table->table[index];
    table->table[index] = new_symbol;

    functionNames[i] = new_symbol->name;
    i++;

    return true;
}

Symbol* lookupSymbol(SymbolTable* table, const char* name) {
    if (!table || !name) return NULL;

    unsigned int index = hash(name, table->size);
    Symbol* current = table->table[index];
    Symbol* found = NULL;
    int highest_scope = -1;

    while (current) {
        if (strcmp(current->name, name) == 0) {
            if (current->scope_level > highest_scope) {
                highest_scope = current->scope_level;
                found = current;
            }
        }
        current = current->next;
    }

    return found;
}

void enterScope(SymbolTable* table) {
    if (!table) return;
    table->current_scope++;
}

void exitScope(SymbolTable* table) {
    if (!table || table->current_scope == 0) return;
    table->current_scope--;
}

const char* getTypeString(SymbolType type) {
    switch (type) {
        case TYPE_INT: return "int";
        case TYPE_FLOAT: return "float";
        case TYPE_BOOL: return "bool";
        case TYPE_FUNCTION: return "function";
        case TYPE_ARRAY: return "array";
        default: return "unknown";
    }
}

void printSymbol(Symbol* symbol) {
    if (!symbol) return;
    
    char additionalInfo[256] = "";  // Buffer for additional information

    // Format additional info based on symbol type
    if (symbol->type == TYPE_ARRAY) {
        snprintf(additionalInfo, sizeof(additionalInfo), "Array size: %d, Element type: %s",
                symbol->array_info.size,
                getTypeString(symbol->array_info.element_type));
    } 
    else if (symbol->type == TYPE_FUNCTION) {
        char paramInfo[200] = "";
        ParameterList* param = symbol->function_info.params;
        while (param) {
            char paramStr[50];
            snprintf(paramStr, sizeof(paramStr), "%s(%s) ", 
                    param->name, getTypeString(param->type));
            strcat(paramInfo, paramStr);
            param = param->next;
        }
        snprintf(additionalInfo, sizeof(additionalInfo), "Return type: %s, Params: %s",
                getTypeString(symbol->function_info.return_type),
                paramInfo);
    }

    // Print the symbol information in a formatted way
    printf("%-20s | %-10s | %-6d | %-11s | %s\n",
           symbol->name,
           getTypeString(symbol->type),
           symbol->scope_level,
           symbol->initialized ? "yes" : "no",
           additionalInfo);
}

void printSymbolTable(SymbolTable* table) {
    if (!table) return;

    printf("\n=== Symbol Table ===\n");
    printf("%-20s | %-10s | %-6s | %-11s | %s\n",
           "Name", "Type", "Scope", "Initialized", "Additional Info");
    printf("--------------------------------------------------------------------------------\n");

    // Print scope 0 (global scope) first
    printf("\nGlobal Scope (0) (Main):\n");
    printf("--------------------------------------------------------------------------------\n");
    bool foundGlobals = false;
    for (int i = 0; i < table->size; i++) {
        Symbol* current = table->table[i];
        while (current) {
            if (current->scope_level == 0) {
                printSymbol(current);
                foundGlobals = true;
            }
            current = current->next;
        }
    }
    if (!foundGlobals) {
        printf("(No global symbols)\n");
    }

    // Track maximum scope seen
    int max_scope = 0;
    for (int i = 0; i < table->size; i++) {
        Symbol* current = table->table[i];
        while (current) {
            if (current->scope_level > max_scope) {
                max_scope = current->scope_level;
            }
            current = current->next;
        }
    }

    int x = 1;
    // Print each scope level
    for (int scope = 1; scope <= max_scope; scope++) {
        bool foundSymbols = false;
        printf("\nScope Level %d ", scope);
        printf(" (Function: %s)\n", functionNames[x]);
        x++;
        printf("--------------------------------------------------------------------------------\n");
        
        for (int i = 0; i < table->size; i++) {
            Symbol* current = table->table[i];
            while (current) {
                if (current->scope_level == scope) {
                    printSymbol(current);
                    foundSymbols = true;
                }
                current = current->next;
            }
        }
        
        if (!foundSymbols) {
            printf("(No symbols in this scope)\n");
        }
    }

    printf("================================================================================\n");
}
