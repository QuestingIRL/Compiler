package main

import (
	"compiler/lexer"
	"compiler/parser"
	"fmt"
	"strings"
)

// Helper function to run a test case
func runTest(name string, input string) {
	fmt.Printf("\n=== Test Case: %s ===\n", name)
	fmt.Println("Input Program:")
	fmt.Println(strings.TrimSpace(input))
	fmt.Println("\nAST Output:")

	l := lexer.New(input)
	p := parser.New(l)

	ast := p.PrintAST()
	fmt.Println(ast)

	if len(p.Errors()) > 0 {
		fmt.Println("\nErrors:")
		for _, err := range p.Errors() {
			fmt.Printf("  - %s\n", err)
		}
	}
	fmt.Println(strings.Repeat("=", 80))
}

func main() {
	// Test 1: Basic Function with All Types
	runTest("Basic Function with All Types", `
		int add(int x, int y) {
			int result;
			result = x + y;
			return result;
		}

		main {
			int a;
			float b;
			bool flag;
			a = 5;
			b = 10.5;
			flag = true;
			return void;
		}
	`)

	// Test 2: Complex Mathematical Expressions
	runTest("Complex Mathematical Expressions", `
		float calculateExpression(float x, float y) {
			float result;
			result = x * y / 2.0 + x + y * 3.0;
			return result;
		}

		main {
			float result;
			result = calculateExpression(5.0, 3.0);
			write result;
			return void;
		}
	`)

	// Test 3: Multiple Functions with Different Return Types
	runTest("Multiple Functions", `
		int getValue() {
			int x;
			x = 42;
			return x;
		}

		float convertToFloat(int x) {
			float result;
			result = x;
			return result;
		}

		bool isPositive(int x) {
			bool result;
			result = true;
			return result;
		}

		main {
			int val;
			float converted;
			bool check;
			val = getValue();
			converted = convertToFloat(val);
			check = isPositive(val);
			return void;
		}
	`)

	// Test 4: Void Functions and Function Calls
	runTest("Void Functions and Calls", `
		void printValue(int x) {
			write x;
			return void;
		}

		int getNumber() {
			int x;
			x = 42;
			return x;
		}

		main {
			int num;
			num = getNumber();
			printValue(num);
			return void;
		}
	`)

	// Test 5: All Arithmetic Operators
	runTest("All Arithmetic Operators", `
		float mathOps(float a, float b) {
			float result;
			result = a + b;
			result = result - b;
			result = result * a;
			result = result / 2.0;
			return result;
		}

		main {
			float x;
			float y;
			float result;
			x = 10.0;
			y = 5.0;
			result = mathOps(x, y);
			write result;
			return void;
		}
	`)

	// Test 6: Multiple Variable Declarations and Assignments
	runTest("Multiple Variables and Assignments", `
		void initialize() {
			int a;
			int b;
			int c;
			float d;
			float e;
			bool flag;
			
			a = 1;
			b = 2;
			c = 3;
			d = 4.0;
			e = 5.0;
			flag = true;
			
			return void;
		}

		main {
			initialize();
			return void;
		}
	`)

	// Test 7: Function with Multiple Parameters
	runTest("Multiple Parameters", `
		float average(int a, int b, float c, float d) {
			float sum;
			float result;
			sum = a + b + c + d;
			result = sum / 4.0;
			return result;
		}

		main {
			float result;
			result = average(1, 2, 3.0, 4.0);
			write result;
			return void;
		}
	`)

	// Test 8: Multiple Write Statements
	runTest("Multiple Write Statements", `
		void printAll(int a, float b) {
			write a;
			write b;
			return void;
		}

		main {
			int x;
			float y;
			x = 42;
			y = 3.14;
			write x;
			write y;
			printAll(x, y);
			return void;
		}
	`)

	// Test 9: Boolean Operations and Values
	runTest("Boolean Operations", `
		bool checkValue(int x) {
			bool result;
			result = true;
			return result;
		}

		main {
			int value;
			bool flag;
			value = 42;
			flag = checkValue(value);
			return void;
		}
	`)

	// Test 10: Complex Function Call Chain
	runTest("Function Call Chain", `
		int first() {
			int x;
			x = 42;
			return x;
		}

		float second(int x) {
			float result;
			result = x;
			return result;
		}

		void third(float x) {
			write x;
			return void;
		}

		main {
			int a;
			float b;
			a = first();
			b = second(a);
			third(b);
			return void;
		}
	`)
}
