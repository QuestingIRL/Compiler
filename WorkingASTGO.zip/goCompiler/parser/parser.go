package parser

import (
	"compiler/ast"
	"compiler/lexer"
	"fmt"
)

// NodeType represents the type of AST node
type NodeType int

const (
	PROGRAM NodeType = iota
	FUNCTION_DECL
	VARIABLE_DECL
	ASSIGNMENT
	WRITE_STMT
	RETURN_STMT
	FUNCTION_CALL
	BINARY_EXPR
	NUMBER_LITERAL
	IDENTIFIER
)

// Node represents a node in the AST
type Node interface {
	TokenLiteral() string
	GetLine() int
}

// Statement represents a statement node
type Statement interface {
	Node
	statementNode()
}

// Expression represents an expression node
type Expression interface {
	Node
	expressionNode()
}

// Program represents the root node of program
type Program struct {
	Functions []FunctionDecl
	Main      *MainBlock
}

func (p *Program) TokenLiteral() string { return "program" }
func (p *Program) GetLine() int         { return 0 }

// FunctionDecl represents a function declaration
type FunctionDecl struct {
	ReturnType string
	Name       string
	Params     []Parameter
	Body       []Statement
	Line       int
}

func (fd *FunctionDecl) statementNode()       {}
func (fd *FunctionDecl) TokenLiteral() string { return fd.Name }
func (fd *FunctionDecl) GetLine() int         { return fd.Line }

// Parameter represents a function parameter
type Parameter struct {
	Type string
	Name string
}

// MainBlock represents the main function block
type MainBlock struct {
	Body []Statement
	Line int
}

func (mb *MainBlock) statementNode()       {}
func (mb *MainBlock) TokenLiteral() string { return "main" }
func (mb *MainBlock) GetLine() int         { return mb.Line }

// VarDecl represents a variable declaration
type VarDecl struct {
	Type string
	Name string
	Line int
}

func (vd *VarDecl) statementNode()       {}
func (vd *VarDecl) TokenLiteral() string { return vd.Name }
func (vd *VarDecl) GetLine() int         { return vd.Line }

// Assignment represents an assignment statement
type Assignment struct {
	Name  string
	Value Expression
	Line  int
}

func (as *Assignment) statementNode()       {}
func (as *Assignment) TokenLiteral() string { return "=" }
func (as *Assignment) GetLine() int         { return as.Line }

// WriteStatement represents a write statement
type WriteStatement struct {
	Expression Expression
	Line       int
}

func (ws *WriteStatement) statementNode()       {}
func (ws *WriteStatement) TokenLiteral() string { return "write" }
func (ws *WriteStatement) GetLine() int         { return ws.Line }

// ReturnStatement represents a return statement
type ReturnStatement struct {
	Value Expression
	Line  int
}

func (rs *ReturnStatement) statementNode()       {}
func (rs *ReturnStatement) TokenLiteral() string { return "return" }
func (rs *ReturnStatement) GetLine() int         { return rs.Line }

// BinaryExpression represents a binary operation
type BinaryExpression struct {
	Left     Expression
	Operator string
	Right    Expression
	Line     int
}

func (be *BinaryExpression) expressionNode()      {}
func (be *BinaryExpression) TokenLiteral() string { return be.Operator }
func (be *BinaryExpression) GetLine() int         { return be.Line }

// NumberLiteral represents a numeric literal
type NumberLiteral struct {
	Value   string
	IsFloat bool
	Line    int
}

func (nl *NumberLiteral) expressionNode()      {}
func (nl *NumberLiteral) TokenLiteral() string { return nl.Value }
func (nl *NumberLiteral) GetLine() int         { return nl.Line }

// Identifier represents a variable or function name
type Identifier struct {
	Value string
	Line  int
}

func (i *Identifier) expressionNode()      {}
func (i *Identifier) TokenLiteral() string { return i.Value }
func (i *Identifier) GetLine() int         { return i.Line }

// FunctionCall represents a function call
type FunctionCall struct {
	Name string
	Args []Expression
	Line int
}

func (fc *FunctionCall) expressionNode()      {}
func (fc *FunctionCall) TokenLiteral() string { return fc.Name }
func (fc *FunctionCall) GetLine() int         { return fc.Line }

// Parser represents the parser
type Parser struct {
	l         *lexer.Lexer
	curToken  lexer.Token
	peekToken lexer.Token
	errors    []string
}

// New creates a new Parser
func New(l *lexer.Lexer) *Parser {
	p := &Parser{l: l}
	// Read two tokens to initialize curToken and peekToken
	p.nextToken()
	p.nextToken()
	return p
}

func (p *Parser) nextToken() {
	p.curToken = p.peekToken
	p.peekToken = p.l.NextToken()
}

// Update ParseProgram to build AST nodes
func (p *Parser) ParseProgram() (*ast.Program, error) {
	program := &ast.Program{
		Functions: []ast.Function{},
	}

	// Parse functions until we find main
	for p.curToken.Type != lexer.MAIN && p.curToken.Type != lexer.EOF {
		if p.curToken.Type == lexer.INT_TYPE || p.curToken.Type == lexer.FLOAT_TYPE ||
			p.curToken.Type == lexer.BOOL || p.curToken.Type == lexer.VOID {
			function, err := p.parseFunctionDecl()
			if err != nil {
				return nil, err
			}

			// Convert FunctionDecl to ast.Function
			astFunction := ast.Function{
				ReturnType: function.ReturnType,
				Name:       function.Name,
				Parameters: make([]ast.Parameter, len(function.Params)),
				Body:       make([]ast.Statement, len(function.Body)),
			}

			// Convert parameters
			for i, param := range function.Params {
				astFunction.Parameters[i] = ast.Parameter{
					Type: param.Type,
					Name: param.Name,
				}
			}

			// Convert body statements
			for i, stmt := range function.Body {
				astFunction.Body[i] = convertToASTStatement(stmt)
			}

			program.Functions = append(program.Functions, astFunction)
		} else {
			return nil, fmt.Errorf("line %d: expected function declaration, got %s",
				p.curToken.Line, p.curToken.Literal)
		}
	}

	// Parse main block
	if p.curToken.Type == lexer.MAIN {
		main, err := p.parseMainBlock()
		if err != nil {
			return nil, err
		}

		astMain := &ast.MainBlock{
			Body: make([]ast.Statement, len(main.Body)),
		}

		// Convert main block statements
		for i, stmt := range main.Body {
			astMain.Body[i] = convertToASTStatement(stmt)
		}

		program.Main = astMain
	} else {
		return nil, fmt.Errorf("line %d: expected main block", p.curToken.Line)
	}

	return program, nil
}
func (p *Parser) parseFunctionDecl() (*FunctionDecl, error) {
	function := &FunctionDecl{Line: p.curToken.Line}

	// Parse return type
	function.ReturnType = p.curToken.Literal
	p.nextToken()

	// Parse function name
	if p.curToken.Type != lexer.IDENT {
		return nil, fmt.Errorf("line %d: expected function name, got %s",
			p.curToken.Line, p.curToken.Literal)
	}
	function.Name = p.curToken.Literal
	p.nextToken()

	// Parse parameters
	if p.curToken.Type != lexer.LPAREN {
		return nil, fmt.Errorf("line %d: expected '(', got %s",
			p.curToken.Line, p.curToken.Literal)
	}
	p.nextToken()

	function.Params = []Parameter{}
	for p.curToken.Type != lexer.RPAREN {
		if p.curToken.Type != lexer.INT_TYPE && p.curToken.Type != lexer.FLOAT_TYPE &&
			p.curToken.Type != lexer.BOOL {
			return nil, fmt.Errorf("line %d: expected parameter type, got %s",
				p.curToken.Line, p.curToken.Literal)
		}
		param := Parameter{Type: p.curToken.Literal}
		p.nextToken()

		if p.curToken.Type != lexer.IDENT {
			return nil, fmt.Errorf("line %d: expected parameter name, got %s",
				p.curToken.Line, p.curToken.Literal)
		}
		param.Name = p.curToken.Literal
		function.Params = append(function.Params, param)
		p.nextToken()

		if p.curToken.Type == lexer.COMMA {
			p.nextToken()
		}
	}
	p.nextToken()

	// Parse function body
	if p.curToken.Type != lexer.LBRACE {
		return nil, fmt.Errorf("line %d: expected '{', got %s",
			p.curToken.Line, p.curToken.Literal)
	}
	p.nextToken()

	function.Body = []Statement{}
	for p.curToken.Type != lexer.RBRACE {
		stmt, err := p.parseStatement()
		if err != nil {
			return nil, err
		}
		function.Body = append(function.Body, stmt)
	}
	p.nextToken()

	return function, nil
}

func (p *Parser) parseMainBlock() (*MainBlock, error) {
	main := &MainBlock{Line: p.curToken.Line}
	p.nextToken()

	if p.curToken.Type != lexer.LBRACE {
		return nil, fmt.Errorf("line %d: expected '{', got %s",
			p.curToken.Line, p.curToken.Literal)
	}
	p.nextToken()

	main.Body = []Statement{}
	for p.curToken.Type != lexer.RBRACE {
		stmt, err := p.parseStatement()
		if err != nil {
			return nil, err
		}
		main.Body = append(main.Body, stmt)
	}
	p.nextToken()

	return main, nil
}

func (p *Parser) parseStatement() (Statement, error) {
	switch p.curToken.Type {
	case lexer.INT_TYPE, lexer.FLOAT_TYPE, lexer.BOOL:
		return p.parseVarDecl()
	case lexer.IDENT:
		if p.peekToken.Type == lexer.ASSIGN {
			return p.parseAssignment()
		} else if p.peekToken.Type == lexer.LPAREN {
			// Handle function call as a statement (for void functions)
			call, err := p.parseFunctionCall()
			if err != nil {
				return nil, err
			}

			// Expect semicolon after function call
			if p.curToken.Type != lexer.SEMICOLON {
				return nil, fmt.Errorf("line %d: expected ';' after function call, got %s",
					p.curToken.Line, p.curToken.Literal)
			}
			p.nextToken() // move past semicolon

			return &VoidFunctionStatement{
				Call: call,
				Line: call.Line,
			}, nil
		}
		return nil, fmt.Errorf("line %d: unexpected identifier %s",
			p.curToken.Line, p.curToken.Literal)
	case lexer.WRITE:
		return p.parseWriteStatement()
	case lexer.RETURN:
		return p.parseReturnStatement()
	default:
		return nil, fmt.Errorf("line %d: unexpected token %s",
			p.curToken.Line, p.curToken.Literal)
	}
}

func (p *Parser) parseVarDecl() (*VarDecl, error) {
	decl := &VarDecl{
		Type: p.curToken.Literal,
		Line: p.curToken.Line,
	}
	p.nextToken()

	if p.curToken.Type != lexer.IDENT {
		return nil, fmt.Errorf("line %d: expected identifier, got %s",
			p.curToken.Line, p.curToken.Literal)
	}
	decl.Name = p.curToken.Literal
	p.nextToken()

	if p.curToken.Type != lexer.SEMICOLON {
		return nil, fmt.Errorf("line %d: expected ';', got %s",
			p.curToken.Line, p.curToken.Literal)
	}
	p.nextToken()

	return decl, nil
}

func (p *Parser) parseAssignment() (*Assignment, error) {
	assign := &Assignment{
		Name: p.curToken.Literal,
		Line: p.curToken.Line,
	}
	p.nextToken() // move past identifier
	p.nextToken() // move past =

	expr, err := p.parseExpression()
	if err != nil {
		return nil, err
	}
	assign.Value = expr

	if p.curToken.Type != lexer.SEMICOLON {
		return nil, fmt.Errorf("line %d: expected ';', got %s",
			p.curToken.Line, p.curToken.Literal)
	}
	p.nextToken()

	return assign, nil
}

func (p *Parser) parseWriteStatement() (*WriteStatement, error) {
	stmt := &WriteStatement{Line: p.curToken.Line}
	p.nextToken()

	expr, err := p.parseExpression()
	if err != nil {
		return nil, err
	}
	stmt.Expression = expr

	if p.curToken.Type != lexer.SEMICOLON {
		return nil, fmt.Errorf("line %d: expected ';', got %s",
			p.curToken.Line, p.curToken.Literal)
	}
	p.nextToken()

	return stmt, nil
}

func (p *Parser) parseReturnStatement() (*ReturnStatement, error) {
	stmt := &ReturnStatement{Line: p.curToken.Line}
	p.nextToken()

	if p.curToken.Type == lexer.VOID {
		stmt.Value = nil
		p.nextToken()
	} else {
		expr, err := p.parseExpression()
		if err != nil {
			return nil, err
		}
		stmt.Value = expr
	}

	if p.curToken.Type != lexer.SEMICOLON {
		return nil, fmt.Errorf("line %d: expected ';', got %s",
			p.curToken.Line, p.curToken.Literal)
	}
	p.nextToken()

	return stmt, nil
}

func (p *Parser) parseExpression() (Expression, error) {
	left, err := p.parsePrimary()
	if err != nil {
		return nil, err
	}

	for p.curToken.Type == lexer.PLUS || p.curToken.Type == lexer.MINUS ||
		p.curToken.Type == lexer.MULTIPLY || p.curToken.Type == lexer.DIVIDE {
		operator := p.curToken.Literal
		operatorLine := p.curToken.Line
		p.nextToken()

		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}

		left = &BinaryExpression{
			Left:     left,
			Operator: operator,
			Right:    right,
			Line:     operatorLine,
		}
	}

	return left, nil
}

func (p *Parser) parsePrimary() (Expression, error) {
	switch p.curToken.Type {
	case lexer.INT, lexer.FLOAT:
		num := &NumberLiteral{
			Value:   p.curToken.Literal,
			IsFloat: p.curToken.Type == lexer.FLOAT,
			Line:    p.curToken.Line,
		}
		p.nextToken()
		return num, nil
	case lexer.IDENT:
		if p.peekToken.Type == lexer.LPAREN {
			return p.parseFunctionCall()
		}
		id := &Identifier{
			Value: p.curToken.Literal,
			Line:  p.curToken.Line,
		}
		p.nextToken()
		return id, nil
	case lexer.TRUE, lexer.FALSE:
		num := &NumberLiteral{
			Value: p.curToken.Literal,
			Line:  p.curToken.Line,
		}
		p.nextToken()
		return num, nil
	default:
		return nil, fmt.Errorf("line %d: unexpected token in expression: %s",
			p.curToken.Line, p.curToken.Literal)
	}
}

func (p *Parser) parseFunctionCall() (*FunctionCall, error) {
	call := &FunctionCall{
		Name: p.curToken.Literal,
		Line: p.curToken.Line,
		Args: []Expression{},
	}
	p.nextToken() // move past identifier
	p.nextToken() // move past (

	// Parse arguments
	for p.curToken.Type != lexer.RPAREN {
		// Only allow identifiers and literals as arguments, no nested calls
		if p.curToken.Type == lexer.IDENT && p.peekToken.Type == lexer.LPAREN {
			return nil, fmt.Errorf("line %d: nested function calls are not allowed",
				p.curToken.Line)
		}

		expr, err := p.parseExpression()
		if err != nil {
			return nil, err
		}
		call.Args = append(call.Args, expr)

		if p.curToken.Type == lexer.COMMA {
			p.nextToken()
		} else if p.curToken.Type != lexer.RPAREN {
			return nil, fmt.Errorf("line %d: expected ',' or ')', got %s",
				p.curToken.Line, p.curToken.Literal)
		}
	}
	p.nextToken() // move past )

	return call, nil
}
func (v *VoidFunctionStatement) statementNode()       {}
func (v *VoidFunctionStatement) TokenLiteral() string { return v.Call.Name }
func (v *VoidFunctionStatement) GetLine() int         { return v.Line }

// Helper functions for token checking
func (p *Parser) expectPeek(t lexer.TokenType) bool {
	if p.peekToken.Type == t {
		p.nextToken()
		return true
	}
	p.errors = append(p.errors, fmt.Sprintf("line %d: expected next token to be %v, got %v instead",
		p.peekToken.Line, t, p.peekToken.Type))
	return false
}

func (p *Parser) currentTokenIs(t lexer.TokenType) bool {
	return p.curToken.Type == t
}

func (p *Parser) peekTokenIs(t lexer.TokenType) bool {
	return p.peekToken.Type == t
}

// Errors returns the parser errors
func (p *Parser) Errors() []string {
	return p.errors
}

// Helper function to check if the current token is an operator
func isOperator(tokenType lexer.TokenType) bool {
	return tokenType == lexer.PLUS || tokenType == lexer.MINUS ||
		tokenType == lexer.MULTIPLY || tokenType == lexer.DIVIDE
}

// Helper function to get operator precedence
func getOperatorPrecedence(tokenType lexer.TokenType) int {
	switch tokenType {
	case lexer.MULTIPLY, lexer.DIVIDE:
		return 2
	case lexer.PLUS, lexer.MINUS:
		return 1
	default:
		return 0
	}
}

// Add new type for void function calls as statements
type VoidFunctionStatement struct {
	Call *FunctionCall
	Line int
}

// Helper function to convert parser statements to AST statements
func convertToASTStatement(stmt Statement) ast.Statement {
	switch s := stmt.(type) {
	case *VarDecl:
		return &ast.VarDeclaration{
			Type: s.Type,
			Name: s.Name,
		}
	case *Assignment:
		return &ast.Assignment{
			Name:  s.Name,
			Value: convertToASTExpression(s.Value),
		}
	case *WriteStatement:
		return &ast.WriteStatement{
			Expression: convertToASTExpression(s.Expression),
		}
	case *ReturnStatement:
		var value ast.Expression
		if s.Value != nil {
			value = convertToASTExpression(s.Value)
		}
		return &ast.ReturnStatement{
			Value: value,
		}
	case *VoidFunctionStatement:
		return &ast.VoidFunctionCall{
			Name:      s.Call.Name,
			Arguments: convertExpressionList(s.Call.Args),
		}
	default:
		panic(fmt.Sprintf("unknown statement type: %T", stmt))
	}
}

// Helper function to convert parser expressions to AST expressions
func convertToASTExpression(expr Expression) ast.Expression {
	switch e := expr.(type) {
	case *NumberLiteral:
		return &ast.NumberLiteral{
			Value:   e.Value,
			IsFloat: e.IsFloat,
		}
	case *Identifier:
		return &ast.Identifier{
			Value: e.Value,
		}
	case *BinaryExpression:
		return &ast.BinaryOperation{
			Left:     convertToASTExpression(e.Left),
			Operator: e.Operator,
			Right:    convertToASTExpression(e.Right),
		}
	case *FunctionCall:
		return &ast.FunctionCall{
			Name:      e.Name,
			Arguments: convertExpressionList(e.Args),
		}
	default:
		panic(fmt.Sprintf("unknown expression type: %T", expr))
	}
}

// Helper function to convert list of expressions
func convertExpressionList(exprs []Expression) []ast.Expression {
	result := make([]ast.Expression, len(exprs))
	for i, expr := range exprs {
		result[i] = convertToASTExpression(expr)
	}
	return result
}

// Add test function to print the AST
func (p *Parser) PrintAST() string {
	program, err := p.ParseProgram()
	if err != nil {
		return fmt.Sprintf("Error parsing program: %v", err)
	}
	return ast.PrintAST(program)
}
