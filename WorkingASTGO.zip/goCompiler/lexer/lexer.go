package lexer

import (
	"strings"
	"unicode"
)

// TokenType represents the type of token
type TokenType int

const (
	ILLEGAL TokenType = iota
	EOF

	// Identifiers + literals
	IDENT // Variable names, function names
	INT   // 123
	FLOAT // 123.45

	// Operators
	ASSIGN   // =
	PLUS     // +
	MINUS    // -
	MULTIPLY // *
	DIVIDE   // /

	// Delimiters
	SEMICOLON // ;
	LPAREN    // (
	RPAREN    // )
	LBRACE    // {
	RBRACE    // }
	COMMA     // ,

	// Keywords
	FUNCTION   // function
	RETURN     // return
	WRITE      // write
	VOID       // void
	BOOL       // bool
	TRUE       // true
	FALSE      // false
	INT_TYPE   // int
	FLOAT_TYPE // float
	MAIN       // main
)

// Token represents a lexical token
type Token struct {
	Type    TokenType
	Literal string
	Line    int
	Column  int
}

// Lexer performs lexical analysis
type Lexer struct {
	input        string
	position     int  // current position in input (points to current char)
	readPosition int  // current reading position in input (after current char)
	ch           byte // current char under examination
	line         int  // current line number
	column       int  // current column number
}

// Keywords map for reserved words
var keywords = map[string]TokenType{
	"main":   MAIN,
	"write":  WRITE,
	"return": RETURN,
	"void":   VOID,
	"bool":   BOOL,
	"true":   TRUE,
	"false":  FALSE,
	"int":    INT_TYPE,
	"float":  FLOAT_TYPE,
}

// New creates a new Lexer
func New(input string) *Lexer {
	l := &Lexer{input: input, line: 1, column: 1}
	l.readChar()
	return l
}

// readChar advances the position in the input string
func (l *Lexer) readChar() {
	if l.readPosition >= len(l.input) {
		l.ch = 0
	} else {
		l.ch = l.input[l.readPosition]
	}

	if l.ch == '\n' {
		l.line++
		l.column = 1
	} else {
		l.column++
	}

	l.position = l.readPosition
	l.readPosition++
}

// peekChar returns the next character without advancing the position
func (l *Lexer) peekChar() byte {
	if l.readPosition >= len(l.input) {
		return 0
	}
	return l.input[l.readPosition]
}

// NextToken returns the next token in the input
func (l *Lexer) NextToken() Token {
	var tok Token

	l.skipWhitespace()

	// Save the start position for error reporting
	startColumn := l.column

	switch l.ch {
	case '=':
		tok = Token{Type: ASSIGN, Literal: string(l.ch), Line: l.line, Column: startColumn}
	case '+':
		tok = Token{Type: PLUS, Literal: string(l.ch), Line: l.line, Column: startColumn}
	case '-':
		tok = Token{Type: MINUS, Literal: string(l.ch), Line: l.line, Column: startColumn}
	case '*':
		tok = Token{Type: MULTIPLY, Literal: string(l.ch), Line: l.line, Column: startColumn}
	case '/':
		tok = Token{Type: DIVIDE, Literal: string(l.ch), Line: l.line, Column: startColumn}
	case ';':
		tok = Token{Type: SEMICOLON, Literal: string(l.ch), Line: l.line, Column: startColumn}
	case '(':
		tok = Token{Type: LPAREN, Literal: string(l.ch), Line: l.line, Column: startColumn}
	case ')':
		tok = Token{Type: RPAREN, Literal: string(l.ch), Line: l.line, Column: startColumn}
	case '{':
		tok = Token{Type: LBRACE, Literal: string(l.ch), Line: l.line, Column: startColumn}
	case '}':
		tok = Token{Type: RBRACE, Literal: string(l.ch), Line: l.line, Column: startColumn}
	case ',':
		tok = Token{Type: COMMA, Literal: string(l.ch), Line: l.line, Column: startColumn}
	case 0:
		tok = Token{Type: EOF, Literal: "", Line: l.line, Column: startColumn}
	default:
		if isLetter(l.ch) {
			tok.Literal = l.readIdentifier()
			tok.Type = lookupIdent(tok.Literal)
			tok.Line = l.line
			tok.Column = startColumn
			return tok
		} else if isDigit(l.ch) {
			return l.readNumber()
		} else {
			tok = Token{Type: ILLEGAL, Literal: string(l.ch), Line: l.line, Column: startColumn}
		}
	}

	l.readChar()
	return tok
}

// skipWhitespace skips any whitespace characters
func (l *Lexer) skipWhitespace() {
	for l.ch == ' ' || l.ch == '\t' || l.ch == '\n' || l.ch == '\r' {
		l.readChar()
	}
}

// readIdentifier reads an identifier or keyword
func (l *Lexer) readIdentifier() string {
	position := l.position
	for isLetter(l.ch) || isDigit(l.ch) {
		l.readChar()
	}
	return l.input[position:l.position]
}

// readNumber reads a number (integer or float)
func (l *Lexer) readNumber() Token {
	startColumn := l.column
	position := l.position
	isFloat := false

	for isDigit(l.ch) || l.ch == '.' {
		if l.ch == '.' {
			if isFloat {
				// Multiple decimal points are not allowed
				return Token{Type: ILLEGAL, Literal: "invalid number format", Line: l.line, Column: startColumn}
			}
			isFloat = true
		}
		l.readChar()
	}

	number := l.input[position:l.position]
	if isFloat {
		return Token{Type: FLOAT, Literal: number, Line: l.line, Column: startColumn}
	}
	return Token{Type: INT, Literal: number, Line: l.line, Column: startColumn}
}

// lookupIdent checks if the identifier is a keyword
func lookupIdent(ident string) TokenType {
	if tok, ok := keywords[strings.ToLower(ident)]; ok {
		return tok
	}
	return IDENT
}

// Helper functions
func isLetter(ch byte) bool {
	return unicode.IsLetter(rune(ch)) || ch == '_'
}

func isDigit(ch byte) bool {
	return unicode.IsDigit(rune(ch))
}
