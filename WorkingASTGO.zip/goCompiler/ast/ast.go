package ast

import (
	"fmt"
	"strings"
)

// Node represents a node in the AST
type Node interface {
	String() string
	PrintNode(indent string) string
}

// Program is the root node of the AST
type Program struct {
	Functions []Function
	Main      *MainBlock
}

func (p *Program) String() string {
	return "Program"
}

func (p *Program) PrintNode(indent string) string {
	var out strings.Builder
	out.WriteString(indent + "Program:\n")

	// Print functions
	for _, fn := range p.Functions {
		out.WriteString(fn.PrintNode(indent + "  "))
	}

	// Print main block
	if p.Main != nil {
		out.WriteString(p.Main.PrintNode(indent + "  "))
	}

	return out.String()
}

// Function represents a function declaration
type Function struct {
	ReturnType string
	Name       string
	Parameters []Parameter
	Body       []Statement
}

func (f *Function) String() string {
	return fmt.Sprintf("Function: %s %s", f.ReturnType, f.Name)
}

func (f *Function) PrintNode(indent string) string {
	var out strings.Builder
	out.WriteString(fmt.Sprintf("%sFunction %s returns %s:\n", indent, f.Name, f.ReturnType))

	// Print parameters
	if len(f.Parameters) > 0 {
		out.WriteString(indent + "  Parameters:\n")
		for _, param := range f.Parameters {
			out.WriteString(param.PrintNode(indent + "    "))
		}
	}

	// Print body
	out.WriteString(indent + "  Body:\n")
	for _, stmt := range f.Body {
		out.WriteString(stmt.PrintNode(indent + "    "))
	}

	return out.String()
}

// Parameter represents a function parameter
type Parameter struct {
	Type string
	Name string
}

func (p *Parameter) String() string {
	return fmt.Sprintf("%s %s", p.Type, p.Name)
}

func (p *Parameter) PrintNode(indent string) string {
	return fmt.Sprintf("%s%s %s\n", indent, p.Type, p.Name)
}

// MainBlock represents the main function
type MainBlock struct {
	Body []Statement
}

func (m *MainBlock) String() string {
	return "Main Block"
}

func (m *MainBlock) PrintNode(indent string) string {
	var out strings.Builder
	out.WriteString(indent + "Main Block:\n")
	for _, stmt := range m.Body {
		out.WriteString(stmt.PrintNode(indent + "  "))
	}
	return out.String()
}

// Statement interface
type Statement interface {
	Node
	statementNode()
}

// VarDeclaration represents a variable declaration
type VarDeclaration struct {
	Type string
	Name string
}

func (v *VarDeclaration) statementNode() {}
func (v *VarDeclaration) String() string {
	return fmt.Sprintf("VarDecl: %s %s", v.Type, v.Name)
}
func (v *VarDeclaration) PrintNode(indent string) string {
	return fmt.Sprintf("%sVariable Declaration: %s %s\n", indent, v.Type, v.Name)
}

// Assignment represents an assignment statement
type Assignment struct {
	Name  string
	Value Expression
}

func (a *Assignment) statementNode() {}
func (a *Assignment) String() string {
	return fmt.Sprintf("Assignment: %s = %s", a.Name, a.Value)
}
func (a *Assignment) PrintNode(indent string) string {
	return fmt.Sprintf("%sAssignment: %s = %s\n", indent, a.Name, a.Value.PrintNode(""))
}

// WriteStatement represents a write statement
type WriteStatement struct {
	Expression Expression
}

func (w *WriteStatement) statementNode() {}
func (w *WriteStatement) String() string {
	return fmt.Sprintf("Write: %s", w.Expression)
}
func (w *WriteStatement) PrintNode(indent string) string {
	return fmt.Sprintf("%sWrite Statement: %s\n", indent, w.Expression.PrintNode(""))
}

// ReturnStatement represents a return statement
type ReturnStatement struct {
	Value Expression // nil for void returns
}

func (r *ReturnStatement) statementNode() {}
func (r *ReturnStatement) String() string {
	if r.Value == nil {
		return "Return: void"
	}
	return fmt.Sprintf("Return: %s", r.Value)
}
func (r *ReturnStatement) PrintNode(indent string) string {
	if r.Value == nil {
		return indent + "Return: void\n"
	}
	return fmt.Sprintf("%sReturn: %s\n", indent, r.Value.PrintNode(""))
}

// VoidFunctionCall represents a void function call statement
type VoidFunctionCall struct {
	Name      string
	Arguments []Expression
}

func (v *VoidFunctionCall) statementNode() {}
func (v *VoidFunctionCall) String() string {
	return fmt.Sprintf("VoidCall: %s", v.Name)
}
func (v *VoidFunctionCall) PrintNode(indent string) string {
	var out strings.Builder
	out.WriteString(fmt.Sprintf("%sVoid Function Call: %s\n", indent, v.Name))
	if len(v.Arguments) > 0 {
		out.WriteString(indent + "  Arguments:\n")
		for _, arg := range v.Arguments {
			out.WriteString(arg.PrintNode(indent + "    "))
		}
	}
	return out.String()
}

// Expression interface
type Expression interface {
	Node
	expressionNode()
}

// BinaryOperation represents a binary operation
type BinaryOperation struct {
	Left     Expression
	Operator string
	Right    Expression
}

func (b *BinaryOperation) expressionNode() {}
func (b *BinaryOperation) String() string {
	return fmt.Sprintf("(%s %s %s)", b.Left, b.Operator, b.Right)
}
func (b *BinaryOperation) PrintNode(indent string) string {
	return fmt.Sprintf("%sBinary Operation: %s\n%sLeft: %s\n%sRight: %s\n",
		indent, b.Operator,
		indent+"  ", b.Left.PrintNode(""),
		indent+"  ", b.Right.PrintNode(""))
}

// NumberLiteral represents a numeric literal
type NumberLiteral struct {
	Value   string
	IsFloat bool
}

func (n *NumberLiteral) expressionNode() {}
func (n *NumberLiteral) String() string {
	return n.Value
}
func (n *NumberLiteral) PrintNode(indent string) string {
	typeStr := "Int"
	if n.IsFloat {
		typeStr = "Float"
	}
	return fmt.Sprintf("%s%s: %s\n", indent, typeStr, n.Value)
}

// BooleanLiteral represents a boolean literal
type BooleanLiteral struct {
	Value bool
}

func (b *BooleanLiteral) expressionNode() {}
func (b *BooleanLiteral) String() string {
	return fmt.Sprintf("%v", b.Value)
}
func (b *BooleanLiteral) PrintNode(indent string) string {
	return fmt.Sprintf("%sBoolean: %v\n", indent, b.Value)
}

// Identifier represents a variable reference
type Identifier struct {
	Value string
}

func (i *Identifier) expressionNode() {}
func (i *Identifier) String() string {
	return i.Value
}
func (i *Identifier) PrintNode(indent string) string {
	return fmt.Sprintf("%sIdentifier: %s\n", indent, i.Value)
}

// FunctionCall represents a function call expression
type FunctionCall struct {
	Name      string
	Arguments []Expression
}

func (f *FunctionCall) expressionNode() {}
func (f *FunctionCall) String() string {
	return fmt.Sprintf("Call: %s", f.Name)
}
func (f *FunctionCall) PrintNode(indent string) string {
	var out strings.Builder
	out.WriteString(fmt.Sprintf("%sFunction Call: %s\n", indent, f.Name))
	if len(f.Arguments) > 0 {
		out.WriteString(indent + "  Arguments:\n")
		for _, arg := range f.Arguments {
			out.WriteString(arg.PrintNode(indent + "    "))
		}
	}
	return out.String()
}

// PrintAST is a helper function to print the entire AST
func PrintAST(node Node) string {
	return node.PrintNode("")
}
