#ifndef AST_H
#define AST_H

#include <stdio.h>

// Enumeration for different node types in the AST
typedef enum {
    NODE_PROGRAM,
    NODE_MAIN_FUNCTION,
    NODE_FUNCTION_LIST,
    NODE_FUNCTION,
    NODE_PARAM_LIST,
    NODE_PARAM,
    NODE_STATEMENT_LIST,
    NODE_STATEMENT,
    NODE_VAR_DECLARATION,
    NODE_ASSIGNMENT,
    NODE_ARRAY_DECLARATION,
    NODE_ARRAY_ASSIGNMENT,
    NODE_RETURN_STATEMENT,
    NODE_EXPRESSION,
    NODE_TERM,
    NODE_FACTOR,
    NODE_ARG_LIST,
    NODE_TYPE,
    NODE_ID,
    NODE_NUMBER,
    NODE_OPERATOR,
    NODE_WRITE_STATEMENT,
    NODE_INT_NUMBER,
    NODE_FLOAT_NUMBER
    } NodeType;

// Structure for an AST node
typedef struct ASTNode {
    NodeType type;          // Type of the node
    char *value;            // Value associated with the node (e.g., identifier names, numbers)
    int numValue;           // Numerical value (if applicable)
    struct ASTNode **children; // Array of pointers to child nodes
    int childCount;         // Number of child nodes
} ASTNode;

// Function prototypes
ASTNode* createNode(NodeType type, char* value);
void addChild(ASTNode* parent, ASTNode* child);
void printAST(ASTNode* node, int indent);
void freeAST(ASTNode* node);

#endif // AST_H
