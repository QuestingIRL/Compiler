#include "st.h"

// Creates a new symbol table with a specified size
SymbolTable* createSymbolTable(int size) {
    SymbolTable* table = (SymbolTable*)malloc(sizeof(SymbolTable));
    if (!table) {
        fprintf(stderr, "Memory allocation failed for symbol table!\n");
        exit(1);
    }
    table->size = size;
    table->table = (Symbol**)calloc(size, sizeof(Symbol*));
    return table;
}

// Hash function to map a symbol name to an index
static int hash(const SymbolTable* table, const char* name) {
    int hashValue = 0;
    for (int i = 0; name[i] != '\0'; i++) {
        hashValue = (hashValue + name[i]) % table->size;
    }
    return hashValue;
}

// Adds a symbol to the symbol table
void addSymbol(SymbolTable* table, char* name, SymType type, SymValue value) {
    int index = hash(table, name);
    Symbol* newSymbol = (Symbol*)malloc(sizeof(Symbol));
    newSymbol->name = strdup(name);
    newSymbol->type = type;
    newSymbol->value = value;
    newSymbol->size = 0;  // Default size to 0 for non-array types
    newSymbol->next = table->table[index];
    table->table[index] = newSymbol;
}

// Look up a symbol by name
Symbol* lookupSymbol(SymbolTable* table, char* name) {
    int index = hash(table, name);
    Symbol* symbol = table->table[index];
    while (symbol) {
        if (strcmp(symbol->name, name) == 0) {
            return symbol;
        }
        symbol = symbol->next;
    }
    return NULL;  // Symbol not found
}

// Adds an array symbol to the table
void addArraySym(SymbolTable* table, char* name, SymType type, SymValue value, int size) {
    int index = hash(table, name);

    // Create a new symbol
    Symbol* newSymbol = (Symbol*)malloc(sizeof(Symbol));
    newSymbol->name = strdup(name);  // Duplicate the array name
    newSymbol->type = type;          // Set the type (int, float, etc.)
    newSymbol->size = size;          // Set the array size

    // Set the value based on the type of the array
    if (type == TYPE_INT) {
        newSymbol->value.intArray = value.intArray;  // Use the int array
    } else if (type == TYPE_FLOAT) {
        newSymbol->value.floatArray = value.floatArray;  // Use the float array
    } else if (type == TYPE_CHAR) {
        newSymbol->value.intArray = value.intArray;  // Use the char array (stored as ints)
    }

    newSymbol->next = table->table[index];  // Insert symbol at the beginning of the linked list
    table->table[index] = newSymbol;  // Add to the symbol table
}


// Adds a function symbol to the table (stub for further details)
void addFunctionSym(SymbolTable* table, char* name) {
    int index = hash(table, name);
    Symbol* newSymbol = (Symbol*)malloc(sizeof(Symbol));
    newSymbol->name = strdup(name);
    newSymbol->type = TYPE_FUNCTION;
    newSymbol->size = 0;  // No array size for functions
    // Placeholder for function parameters, etc.
    newSymbol->next = table->table[index];
    table->table[index] = newSymbol;
}

void printSymbolTable(const SymbolTable* table) {
    printf("Symbol Table:\n");
    for (int i = 0; i < table->size; i++) {
        Symbol* symbol = table->table[i];
        while (symbol) {
            // Print the name for all types
            printf("Name: %s", symbol->name);

            // Check for array and print type along with the array size
            if (symbol->size > 0) {
                // If it's an array, print the type and size of the array
                if (symbol->type == TYPE_INT) {
                    printf(", Type: INT ARRAY, Size: %d", symbol->size);
                } else if (symbol->type == TYPE_FLOAT) {
                    printf(", Type: FLOAT ARRAY, Size: %d", symbol->size);
                } else if (symbol->type == TYPE_CHAR) {
                    printf(", Type: CHAR ARRAY, Size: %d", symbol->size);
                }
            }
            else if (symbol->type == TYPE_INT) {  // Not an array, regular integer
                printf(", Type: INT, Value: %d", symbol->value.intValue);
            } 
            else if (symbol->type == TYPE_FLOAT) {  // Not an array, regular float
                printf(", Type: FLOAT, Value: %f", symbol->value.floatValue);
            } 
            else if (symbol->type == TYPE_CHAR) {  // Not an array, regular char
                printf(", Type: CHAR, Value: %c", symbol->value.charValue);
            }
            else if (symbol->type == TYPE_FUNCTION) {
                // For functions, just print the name
                printf(", Type: FUNCTION");
            }

            printf("\n");
            symbol = symbol->next;
        }
    }
}






// Frees all memory used by the symbol table
void freeSymbolTable(SymbolTable* table) {
    for (int i = 0; i < table->size; i++) {
        Symbol* symbol = table->table[i];
        while (symbol) {
            Symbol* temp = symbol;
            symbol = symbol->next;
            free(temp->name);
            free(temp);
        }
    }
    free(table->table);
    free(table);
}
