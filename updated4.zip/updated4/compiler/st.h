#ifndef ST_H
#define ST_H

// includes
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>

// symbol type
typedef enum {
    TYPE_INT,
    TYPE_FLOAT,
    TYPE_CHAR,
    TYPE_FUNCTION,
    TYPE_ARRAY
} SymType;

// value
typedef union {
    int intValue;
    float floatValue;
    char charValue;
    int* intArray;
    float* floatArray;
    int size;
} SymValue;

// symbol structure
typedef struct Symbol {
    char* name;
    SymType type;
    SymValue value;
    int size;
    struct Symbol* next;
} Symbol;

// symbol table structure
typedef struct SymbolTable {
    int size;
    struct Symbol** table;
} SymbolTable;

// Functions
// Function prototypes
SymbolTable* createSymbolTable(int size);
void addSymbol(SymbolTable* table, char* name, SymType type, SymValue value);
Symbol* lookupSymbol(SymbolTable* table, char* name);
void freeSymbolTable(SymbolTable* table);
void printSymbolTable(const SymbolTable* table);

// New Stuff
void addArraySym(SymbolTable* table, char* name, SymType type, SymValue value, int size);  // need to implement
void addFunctionSym(SymbolTable* table, char* name);  // need to implement

#endif